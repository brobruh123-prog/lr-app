
-- helper: is_parent_of_student
create or replace function public.is_parent_of_student(_user_id uuid, _student_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.parent_student_links psl
    join public.parents p on p.id = psl.parent_id
    where psl.student_id = _student_id and p.user_id = _user_id
  )
$$;

-- helper: is_self_student
create or replace function public.is_self_student(_user_id uuid, _student_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.students s where s.id = _student_id and s.user_id = _user_id)
$$;

-- LIFEPACs
create table public.lifepacs (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  unit_number int not null,
  title text not null,
  status text not null default 'pending' check (status in ('pending','in_progress','completed')),
  progress_percent int not null default 0 check (progress_percent between 0 and 100),
  teacher_comment text,
  started_at date,
  completed_at date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, subject_id, unit_number)
);
grant select, insert, update, delete on public.lifepacs to authenticated;
grant all on public.lifepacs to service_role;
alter table public.lifepacs enable row level security;
create policy "lifepacs admin all" on public.lifepacs for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "lifepacs teacher all" on public.lifepacs for all to authenticated using (public.has_role(auth.uid(),'teacher')) with check (public.has_role(auth.uid(),'teacher'));
create policy "lifepacs student read" on public.lifepacs for select to authenticated using (public.is_self_student(auth.uid(), student_id));
create policy "lifepacs parent read" on public.lifepacs for select to authenticated using (public.is_parent_of_student(auth.uid(), student_id));
create trigger lifepacs_updated_at before update on public.lifepacs for each row execute function public.set_updated_at();

-- Grade entries
create table public.grade_entries (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  class_id uuid references public.classes(id) on delete set null,
  teacher_id uuid references public.teachers(id) on delete set null,
  category text not null check (category in ('quiz','test','assignment','exam','project','homework')),
  title text not null,
  score numeric(6,2) not null,
  max_score numeric(6,2) not null check (max_score > 0),
  weight numeric(5,2) not null default 1.0,
  term text not null default 'Term 1',
  recorded_at date not null default current_date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.grade_entries to authenticated;
grant all on public.grade_entries to service_role;
alter table public.grade_entries enable row level security;
create policy "grades admin all" on public.grade_entries for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "grades teacher all" on public.grade_entries for all to authenticated using (public.has_role(auth.uid(),'teacher')) with check (public.has_role(auth.uid(),'teacher'));
create policy "grades student read" on public.grade_entries for select to authenticated using (public.is_self_student(auth.uid(), student_id));
create policy "grades parent read" on public.grade_entries for select to authenticated using (public.is_parent_of_student(auth.uid(), student_id));
create trigger grades_updated_at before update on public.grade_entries for each row execute function public.set_updated_at();
create index grade_entries_student_idx on public.grade_entries(student_id);
create index grade_entries_subject_idx on public.grade_entries(subject_id);

-- Attendance
create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid references public.classes(id) on delete set null,
  date date not null default current_date,
  status text not null check (status in ('present','absent','tardy','excused')),
  notes text,
  recorded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, date)
);
grant select, insert, update, delete on public.attendance to authenticated;
grant all on public.attendance to service_role;
alter table public.attendance enable row level security;
create policy "att admin all" on public.attendance for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "att teacher all" on public.attendance for all to authenticated using (public.has_role(auth.uid(),'teacher')) with check (public.has_role(auth.uid(),'teacher'));
create policy "att student read" on public.attendance for select to authenticated using (public.is_self_student(auth.uid(), student_id));
create policy "att parent read" on public.attendance for select to authenticated using (public.is_parent_of_student(auth.uid(), student_id));
create trigger attendance_updated_at before update on public.attendance for each row execute function public.set_updated_at();
create index attendance_student_date_idx on public.attendance(student_id, date desc);

-- Aggregates
create or replace function public.student_subject_average(_student_id uuid, _subject_id uuid)
returns numeric language sql stable security definer set search_path = public as $$
  select case when sum(weight * max_score) = 0 then null
              else round(100 * sum(weight * score) / sum(weight * max_score), 2) end
  from public.grade_entries where student_id = _student_id and subject_id = _subject_id
$$;

create or replace function public.student_gpa(_student_id uuid)
returns numeric language sql stable security definer set search_path = public as $$
  with subj as (
    select subject_id,
           case when sum(weight * max_score) = 0 then null
                else sum(weight * score) / sum(weight * max_score) end as pct
    from public.grade_entries where student_id = _student_id group by subject_id
  ), gp as (
    select case
      when pct >= 0.93 then 4.0 when pct >= 0.90 then 3.7
      when pct >= 0.87 then 3.3 when pct >= 0.83 then 3.0 when pct >= 0.80 then 2.7
      when pct >= 0.77 then 2.3 when pct >= 0.73 then 2.0 when pct >= 0.70 then 1.7
      when pct >= 0.67 then 1.3 when pct >= 0.63 then 1.0 when pct >= 0.60 then 0.7
      else 0.0 end as gp from subj where pct is not null
  ) select round(avg(gp)::numeric, 2) from gp
$$;

create or replace function public.student_attendance_rate(_student_id uuid)
returns numeric language sql stable security definer set search_path = public as $$
  select case when count(*) = 0 then null
              else round(100.0 * sum(case when status in ('present','tardy','excused') then 1 else 0 end) / count(*), 1) end
  from public.attendance where student_id = _student_id
$$;
