
create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create policy "users see own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create table public.gallery_photos (
  id uuid primary key default gen_random_uuid(),
  image_path text not null,
  caption text,
  category text not null default 'general',
  sort_order int not null default 0,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

grant select on public.gallery_photos to anon, authenticated;
grant insert, update, delete on public.gallery_photos to authenticated;
grant all on public.gallery_photos to service_role;
alter table public.gallery_photos enable row level security;

create policy "anyone can view photos" on public.gallery_photos
  for select to anon, authenticated using (true);
create policy "admins can insert photos" on public.gallery_photos
  for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "admins can update photos" on public.gallery_photos
  for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "admins can delete photos" on public.gallery_photos
  for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
