
-- Updated-at helper
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- PROFILES
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text, avatar_url text, phone text, email text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)))
  ON CONFLICT (id) DO NOTHING;
  IF NEW.email IN ('brukmeb123@gmail.com','brukambes@gmail.com') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id,'admin') ON CONFLICT DO NOTHING;
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id,'student') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- SUBJECTS
CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE, code text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.subjects TO authenticated;
GRANT ALL ON public.subjects TO service_role;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read subjects" ON public.subjects FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage subjects" ON public.subjects FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- TEACHERS
CREATE TABLE public.teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL, email text, phone text, title text,
  subject_ids uuid[] DEFAULT '{}', bio text, avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.teachers TO authenticated;
GRANT ALL ON public.teachers TO service_role;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read teachers" ON public.teachers FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage teachers" ON public.teachers FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER teachers_updated BEFORE UPDATE ON public.teachers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- CLASSES
CREATE TABLE public.classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, grade_level text NOT NULL,
  academic_year text NOT NULL DEFAULT '2025-2026',
  homeroom_teacher_id uuid REFERENCES public.teachers(id) ON DELETE SET NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.classes TO authenticated;
GRANT ALL ON public.classes TO service_role;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read classes" ON public.classes FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage classes" ON public.classes FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER classes_updated BEFORE UPDATE ON public.classes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- STUDENTS
CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE SET NULL,
  student_code text UNIQUE, full_name text NOT NULL,
  date_of_birth date, gender text, grade_level text,
  class_id uuid REFERENCES public.classes(id) ON DELETE SET NULL,
  enrollment_date date DEFAULT CURRENT_DATE,
  avatar_url text, notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.students TO authenticated;
GRANT ALL ON public.students TO service_role;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin manage students" ON public.students FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "students see self" ON public.students FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "teachers see students" ON public.students FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'teacher'));
CREATE TRIGGER students_updated BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- PARENTS
CREATE TABLE public.parents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL, email text, phone text, relationship text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.parents TO authenticated;
GRANT ALL ON public.parents TO service_role;
ALTER TABLE public.parents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin manage parents" ON public.parents FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "parents see self" ON public.parents FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE TRIGGER parents_updated BEFORE UPDATE ON public.parents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- PARENT <-> STUDENT
CREATE TABLE public.parent_student_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid NOT NULL REFERENCES public.parents(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  relationship text DEFAULT 'parent',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (parent_id, student_id)
);
GRANT SELECT ON public.parent_student_links TO authenticated;
GRANT ALL ON public.parent_student_links TO service_role;
ALTER TABLE public.parent_student_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin manage links" ON public.parent_student_links FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "parents see own links" ON public.parent_student_links FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.parents p WHERE p.id = parent_id AND p.user_id = auth.uid())
);

-- ENROLLMENTS
CREATE TABLE public.enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  academic_year text NOT NULL DEFAULT '2025-2026',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, class_id, academic_year)
);
GRANT SELECT ON public.enrollments TO authenticated;
GRANT ALL ON public.enrollments TO service_role;
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin manage enrollments" ON public.enrollments FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "student sees own enrollment" ON public.enrollments FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.students s WHERE s.id = student_id AND s.user_id = auth.uid())
);
CREATE POLICY "parent sees child enrollment" ON public.enrollments FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.parent_student_links l JOIN public.parents p ON p.id = l.parent_id
          WHERE l.student_id = enrollments.student_id AND p.user_id = auth.uid())
);
CREATE POLICY "teacher sees enrollments" ON public.enrollments FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'teacher'));

-- ANNOUNCEMENTS
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL, body text NOT NULL,
  audience text NOT NULL DEFAULT 'all',
  class_id uuid REFERENCES public.classes(id) ON DELETE CASCADE,
  pinned boolean NOT NULL DEFAULT false,
  is_public boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.announcements TO authenticated;
GRANT SELECT ON public.announcements TO anon;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anon reads public ann" ON public.announcements FOR SELECT TO anon USING (is_public = true);
CREATE POLICY "authed reads ann" ON public.announcements FOR SELECT TO authenticated USING (true);
CREATE POLICY "staff manage ann" ON public.announcements FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'teacher'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'teacher'));
CREATE TRIGGER announcements_updated BEFORE UPDATE ON public.announcements FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- NOTIFICATIONS
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL, body text, link text,
  category text DEFAULT 'general',
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "see own notif" ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "mark own notif" ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "admin manage notif" ON public.notifications FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE INDEX idx_students_class ON public.students(class_id);
CREATE INDEX idx_enrollments_student ON public.enrollments(student_id);
CREATE INDEX idx_enrollments_class ON public.enrollments(class_id);
CREATE INDEX idx_ann_created ON public.announcements(created_at DESC);
CREATE INDEX idx_notif_user ON public.notifications(user_id, read_at);

-- SEED
INSERT INTO public.subjects (name, code) VALUES
 ('Bible','BIB'),('Mathematics','MATH'),('English','ENG'),('Science','SCI'),
 ('History','HIST'),('Kinyarwanda','KIN'),('French','FR'),('Physical Education','PE');

INSERT INTO public.teachers (full_name, email, title, bio) VALUES
 ('Grace Mukamana','grace.m@liferoots.rw','Lead Bible Teacher','Passionate about discipling students.'),
 ('Jean-Paul Habimana','jp.h@liferoots.rw','Mathematics Teacher','Loves making numbers click.'),
 ('Sarah Uwase','sarah.u@liferoots.rw','English & Literature','Encourages a love of reading.');

INSERT INTO public.classes (name, grade_level, academic_year, description) VALUES
 ('Kindergarten A','Kindergarten','2025-2026','Our youngest learners.'),
 ('Grade 4 Eagles','Grade 4','2025-2026','Elementary curious minds.'),
 ('Grade 8 Pioneers','Grade 8','2025-2026','Middle school leaders.'),
 ('Grade 11 Scholars','Grade 11','2025-2026','High school college-prep.');

INSERT INTO public.students (student_code, full_name, grade_level, gender) VALUES
 ('LR-2025-001','Aline Iradukunda','Grade 4','F'),
 ('LR-2025-002','Eric Niyonsenga','Grade 4','M'),
 ('LR-2025-003','Diane Mahoro','Grade 8','F'),
 ('LR-2025-004','Patrick Shema','Grade 11','M'),
 ('LR-2025-005','Joy Ineza','Kindergarten','F');

INSERT INTO public.parents (full_name, email, phone, relationship) VALUES
 ('Claude Iradukunda','claude.i@example.com','+250788111222','Father'),
 ('Esther Mahoro','esther.m@example.com','+250788333444','Mother');

INSERT INTO public.parent_student_links (parent_id, student_id, relationship)
SELECT p.id, s.id, p.relationship FROM public.parents p, public.students s
WHERE (p.full_name='Claude Iradukunda' AND s.full_name='Aline Iradukunda')
   OR (p.full_name='Esther Mahoro' AND s.full_name='Diane Mahoro');

INSERT INTO public.enrollments (student_id, class_id)
SELECT s.id, c.id FROM public.students s
JOIN public.classes c ON (
 (s.grade_level='Kindergarten' AND c.name='Kindergarten A') OR
 (s.grade_level='Grade 4' AND c.name='Grade 4 Eagles') OR
 (s.grade_level='Grade 8' AND c.name='Grade 8 Pioneers') OR
 (s.grade_level='Grade 11' AND c.name='Grade 11 Scholars')
);
UPDATE public.students s SET class_id = e.class_id FROM public.enrollments e WHERE e.student_id = s.id;

INSERT INTO public.announcements (title, body, audience, pinned, is_public) VALUES
 ('Welcome to the 2025-2026 School Year','We are thrilled to welcome students and families back to Liferoots. May this year be filled with growth, learning, and faith.','all',true,true),
 ('Parent-Teacher Conference','Conferences will be held on Saturday, October 18. Sign up via the parent portal.','parents',false,false),
 ('Chapel Schedule','Weekly chapel every Wednesday at 10am. Parents welcome.','all',false,true);
