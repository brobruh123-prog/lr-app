
create policy "anyone view gallery" on storage.objects
  for select to anon, authenticated using (bucket_id = 'gallery');
create policy "admin upload gallery" on storage.objects
  for insert to authenticated with check (bucket_id = 'gallery' and public.has_role(auth.uid(), 'admin'));
create policy "admin update gallery" on storage.objects
  for update to authenticated using (bucket_id = 'gallery' and public.has_role(auth.uid(), 'admin'));
create policy "admin delete gallery" on storage.objects
  for delete to authenticated using (bucket_id = 'gallery' and public.has_role(auth.uid(), 'admin'));
