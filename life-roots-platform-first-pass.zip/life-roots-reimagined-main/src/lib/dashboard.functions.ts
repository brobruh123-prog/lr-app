import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type Role = "admin" | "teacher" | "student" | "parent" | null;

export const getMyRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ role: Role; email: string | null; fullName: string | null }> => {
    const { supabase, userId, claims } = context;
    const email = (claims?.email as string | undefined) ?? null;

    // Auto-claim admin for whitelist
    if (email && ["brukmeb123@gmail.com", "brukambes@gmail.com"].includes(email.toLowerCase())) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: userId, role: "admin" }, { onConflict: "user_id,role", ignoreDuplicates: true });
    }

    const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userId);
    const list = (roles ?? []).map((r) => r.role as string);
    const role: Role = list.includes("admin")
      ? "admin"
      : list.includes("teacher")
        ? "teacher"
        : list.includes("parent")
          ? "parent"
          : list.includes("student")
            ? "student"
            : null;

    const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", userId).maybeSingle();
    return { role, email, fullName: profile?.full_name ?? null };
  });

export const getAdminOverview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const [students, teachers, parents, classes, announcements] = await Promise.all([
      supabase.from("students").select("id", { count: "exact", head: true }),
      supabase.from("teachers").select("id", { count: "exact", head: true }),
      supabase.from("parents").select("id", { count: "exact", head: true }),
      supabase.from("classes").select("id", { count: "exact", head: true }),
      supabase.from("announcements").select("*").order("created_at", { ascending: false }).limit(5),
    ]);
    return {
      counts: {
        students: students.count ?? 0,
        teachers: teachers.count ?? 0,
        parents: parents.count ?? 0,
        classes: classes.count ?? 0,
      },
      announcements: announcements.data ?? [],
    };
  });

export const getAnnouncements = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("announcements")
      .select("*")
      .order("pinned", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(8);
    return data ?? [];
  });
