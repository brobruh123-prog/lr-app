import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ADMIN_EMAILS = new Set([
  "brukmeb123@gmail.com",
  "brukambes@gmail.com",
]);

/**
 * If the signed-in user's email is on the admin whitelist, ensure they have the
 * 'admin' role in user_roles. Safe to call any time after login.
 */
export const claimAdminIfWhitelisted = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const email = (context.claims?.email as string | undefined)?.toLowerCase();
    if (!email || !ADMIN_EMAILS.has(email)) {
      return { isAdmin: false };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .upsert(
        { user_id: context.userId, role: "admin" },
        { onConflict: "user_id,role", ignoreDuplicates: true },
      );
    if (error) throw new Error(error.message);
    return { isAdmin: true };
  });
