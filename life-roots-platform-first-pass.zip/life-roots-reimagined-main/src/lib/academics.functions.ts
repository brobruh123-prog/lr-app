import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Ctx = { supabase: any; userId: string };

async function resolveStudentIdsForUser(ctx: Ctx, requested?: string | null): Promise<string[]> {
  const { supabase, userId } = ctx;
  // admin or teacher? -> can see anyone (return requested only)
  const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  const r = (roles ?? []).map((x: any) => x.role);
  if (r.includes("admin") || r.includes("teacher")) return requested ? [requested] : [];

  // self student
  const { data: selfStudent } = await supabase.from("students").select("id").eq("user_id", userId).maybeSingle();
  if (selfStudent?.id) return [selfStudent.id];

  // parent links
  const { data: parent } = await supabase.from("parents").select("id").eq("user_id", userId).maybeSingle();
  if (parent?.id) {
    const { data: links } = await supabase.from("parent_student_links").select("student_id").eq("parent_id", parent.id);
    const ids = (links ?? []).map((l: any) => l.student_id);
    if (requested && ids.includes(requested)) return [requested];
    return ids;
  }
  return [];
}

export const getMyChildren = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    // Try parent
    const { data: parent } = await supabase.from("parents").select("id, full_name").eq("user_id", userId).maybeSingle();
    if (parent) {
      const { data: links } = await supabase
        .from("parent_student_links")
        .select("student_id, students:students(id, full_name, grade_level, avatar_url, class_id)")
        .eq("parent_id", parent.id);
      return (links ?? []).map((l: any) => l.students).filter(Boolean);
    }
    // Self student fallback
    const { data: self } = await supabase
      .from("students").select("id, full_name, grade_level, avatar_url, class_id").eq("user_id", userId).maybeSingle();
    return self ? [self] : [];
  });

export const getStudentSnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { studentId?: string | null }) => d)
  .handler(async ({ data, context }) => {
    const ids = await resolveStudentIdsForUser(context, data.studentId);
    const studentId = ids[0];
    if (!studentId) return null;
    const { supabase } = context;

    const [{ data: student }, { data: gpa }, { data: att }, { data: lifepacs }, { data: grades }, { data: attendance }, { data: subjects }] = await Promise.all([
      supabase.from("students").select("id, full_name, grade_level, avatar_url, class_id").eq("id", studentId).maybeSingle(),
      supabase.rpc("student_gpa", { _student_id: studentId }),
      supabase.rpc("student_attendance_rate", { _student_id: studentId }),
      supabase.from("lifepacs").select("id, unit_number, title, status, progress_percent, teacher_comment, subjects:subjects(name, code)").eq("student_id", studentId).order("unit_number"),
      supabase.from("grade_entries").select("id, category, title, score, max_score, weight, term, recorded_at, subjects:subjects(name, code)").eq("student_id", studentId).order("recorded_at", { ascending: false }).limit(50),
      supabase.from("attendance").select("id, date, status").eq("student_id", studentId).order("date", { ascending: false }).limit(60),
      supabase.from("subjects").select("id, name, code"),
    ]);

    // Subject averages
    const averages: Record<string, number | null> = {};
    if (subjects) {
      await Promise.all(subjects.map(async (s: any) => {
        const { data } = await supabase.rpc("student_subject_average", { _student_id: studentId, _subject_id: s.id });
        averages[s.code] = data as number | null;
      }));
    }

    return {
      student,
      gpa: gpa as number | null,
      attendanceRate: att as number | null,
      lifepacs: lifepacs ?? [],
      grades: grades ?? [],
      attendance: attendance ?? [],
      subjects: subjects ?? [],
      averages,
    };
  });

export const getTeacherWorkspace = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const [{ data: classes }, { data: students }, { data: subjects }] = await Promise.all([
      supabase.from("classes").select("id, name, grade_level, academic_year").order("grade_level"),
      supabase.from("students").select("id, full_name, grade_level, class_id, avatar_url").order("full_name"),
      supabase.from("subjects").select("id, name, code").order("name"),
    ]);
    return { classes: classes ?? [], students: students ?? [], subjects: subjects ?? [] };
  });

export const getClassRoster = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { classId: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: students } = await context.supabase
      .from("students").select("id, full_name, grade_level, avatar_url").eq("class_id", data.classId).order("full_name");
    return students ?? [];
  });

export const recordGrade = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    studentId: string; subjectId: string; classId?: string | null;
    category: string; title: string; score: number; maxScore: number; weight?: number; term?: string;
  }) => d)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("grade_entries").insert({
      student_id: data.studentId, subject_id: data.subjectId, class_id: data.classId ?? null,
      category: data.category, title: data.title, score: data.score, max_score: data.maxScore,
      weight: data.weight ?? 1.0, term: data.term ?? "Term 1",
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const recordAttendance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { entries: { studentId: string; classId?: string | null; date: string; status: string }[] }) => d)
  .handler(async ({ data, context }) => {
    const rows = data.entries.map((e) => ({
      student_id: e.studentId, class_id: e.classId ?? null, date: e.date, status: e.status,
      recorded_by: context.userId,
    }));
    const { error } = await context.supabase.from("attendance").upsert(rows, { onConflict: "student_id,date" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const upsertLifepac = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id?: string; studentId: string; subjectId: string; unitNumber: number; title: string; status: string; progressPercent: number; teacherComment?: string }) => d)
  .handler(async ({ data, context }) => {
    const row = {
      id: data.id, student_id: data.studentId, subject_id: data.subjectId,
      unit_number: data.unitNumber, title: data.title, status: data.status,
      progress_percent: data.progressPercent, teacher_comment: data.teacherComment ?? null,
      started_at: data.status !== "pending" ? new Date().toISOString().slice(0, 10) : null,
      completed_at: data.status === "completed" ? new Date().toISOString().slice(0, 10) : null,
    };
    const { error } = await context.supabase.from("lifepacs").upsert(row, { onConflict: "student_id,subject_id,unit_number" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
