import { Link } from "@tanstack/react-router";
import { ArrowRight, BookOpen, Calendar, Check, Clock, Compass, Users } from "lucide-react";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/shared";

export type ProgramDetailProps = {
  eyebrow: string;
  title: string;
  subtitle: string;
  image: string;
  ageRange: string;
  daysPerWeek: string;
  ratio: string;
  subjects: string[];
  outcomes: string[];
  schedule: Array<{ time: string; block: string }>;
  about: string[];
};

export function ProgramDetail(p: ProgramDetailProps) {
  return (
    <PageLayout>
      <PageHero
        eyebrow={p.eyebrow}
        breadcrumb={[{ label: "Programs", to: "/programs" }, { label: p.title }]}
        title={p.title}
        subtitle={p.subtitle}
        image={p.image}
      />

      <section className="container-app py-20">
        <div className="grid gap-6 sm:grid-cols-3">
          {[
            { icon: Users, k: "Age Range", v: p.ageRange },
            { icon: Calendar, k: "Schedule", v: p.daysPerWeek },
            { icon: Compass, k: "Student : Teacher", v: p.ratio },
          ].map((it) => (
            <div key={it.k} className="rounded-3xl border border-navy/10 bg-white p-6 shadow-soft">
              <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-green text-cream"><it.icon size={20} /></span>
              <div className="mt-4 text-xs font-semibold uppercase tracking-wider text-navy/60">{it.k}</div>
              <div className="mt-1 font-display text-xl font-bold text-navy">{it.v}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="container-app pb-20">
        <div className="grid gap-14 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">About this program</h2></Reveal>
            <div className="mt-6 space-y-4 text-navy/75 leading-relaxed">
              {p.about.map((para, i) => (
                <Reveal key={i} delay={i * 60}><p>{para}</p></Reveal>
              ))}
            </div>

            <h3 className="mt-12 font-display text-2xl font-bold text-navy">Subjects</h3>
            <div className="mt-5 flex flex-wrap gap-2">
              {p.subjects.map((s) => (
                <span key={s} className="rounded-full border border-navy/15 bg-cream px-4 py-1.5 text-sm font-medium text-navy">{s}</span>
              ))}
            </div>

            <h3 className="mt-12 font-display text-2xl font-bold text-navy">Learning outcomes</h3>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {p.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-3 rounded-xl border border-navy/10 bg-white px-4 py-3">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-green text-cream"><Check size={12} /></span>
                  <span className="text-sm text-navy">{o}</span>
                </li>
              ))}
            </ul>
          </div>

          <aside className="space-y-6">
            <div className="rounded-3xl border border-navy/10 bg-navy p-7 text-cream shadow-soft">
              <BookOpen size={20} className="text-green-leaf" />
              <h3 className="mt-4 font-display text-xl font-bold">A sample day</h3>
              <ul className="mt-5 space-y-3">
                {p.schedule.map((s) => (
                  <li key={s.time} className="flex items-start gap-3 border-t border-cream/10 pt-3 first:border-0 first:pt-0">
                    <Clock size={14} className="mt-1 text-green-leaf" />
                    <div>
                      <div className="text-xs font-semibold text-green-leaf">{s.time}</div>
                      <div className="text-sm">{s.block}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-3xl border border-green/30 bg-green/5 p-7">
              <h3 className="font-display text-xl font-bold text-navy">Ready to enrol?</h3>
              <p className="mt-2 text-sm text-navy/70">Start your application or book a campus visit to learn more.</p>
              <div className="mt-5 flex flex-col gap-2">
                <Link to="/admissions/apply" className="inline-flex items-center justify-center gap-2 rounded-full bg-green px-5 py-2.5 text-sm font-semibold text-cream hover:bg-green-soft">
                  Apply Now <ArrowRight size={14} />
                </Link>
                <Link to="/admissions/visit" className="inline-flex items-center justify-center gap-2 rounded-full border border-navy/15 px-5 py-2.5 text-sm font-semibold text-navy hover:bg-navy hover:text-cream">
                  Book a visit
                </Link>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
