import type { ReactNode } from "react";
import { SiteNav } from "./SiteNav";
import { SiteFooter } from "./SiteFooter";

export function PageLayout({ children, transparentNav = false }: { children: ReactNode; transparentNav?: boolean }) {
  return (
    <div className="min-h-screen overflow-x-clip bg-cream text-navy">
      <SiteNav transparent={transparentNav} />
      <main>{children}</main>
      <SiteFooter />
    </div>
  );
}
