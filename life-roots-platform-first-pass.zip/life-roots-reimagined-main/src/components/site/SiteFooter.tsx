import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone, Send, Sprout } from "lucide-react";

const COLS: Array<{ heading: string; links: Array<{ label: string; to: string }> }> = [
  { heading: "Academics", links: [
    { label: "Programs", to: "/programs" },
    { label: "Preschool", to: "/programs/preschool" },
    { label: "Elementary", to: "/programs/elementary" },
    { label: "Middle School", to: "/programs/middle-school" },
    { label: "High School", to: "/programs/high-school" },
  ]},
  { heading: "Curriculum", links: [
    { label: "Overview", to: "/curriculum" },
    { label: "LIFEPAC", to: "/curriculum/lifepac" },
    { label: "Sevenstar Online", to: "/curriculum/sevenstar" },
    { label: "Canada Pathway", to: "/curriculum/cpp" },
  ]},
  { heading: "School", links: [
    { label: "About", to: "/about" },
    { label: "Faith", to: "/faith" },
    { label: "Campus", to: "/campus" },
    { label: "News", to: "/news" },
    { label: "FAQ", to: "/faq" },
  ]},
  { heading: "Admissions", links: [
    { label: "How to apply", to: "/admissions" },
    { label: "Apply Now", to: "/admissions/apply" },
    { label: "Book a visit", to: "/admissions/visit" },
    { label: "Contact", to: "/contact" },
  ]},
];

export function SiteFooter() {
  return (
    <footer className="relative bg-navy text-cream">
      <div className="container-app py-16">
        <div className="grid gap-12 lg:grid-cols-[1.2fr_2fr]">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-green text-cream">
                <Sprout size={20} />
              </span>
              <span className="font-display text-xl font-bold">
                Life Roots <span className="font-normal opacity-70">Schools</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm text-cream/70">
              A Christ-centered international school in Kigali, Rwanda — developing students who are academically strong, spiritually grounded, and globally prepared.
            </p>
            <div className="mt-6 space-y-2 text-sm text-cream/80">
              <div className="flex items-center gap-2"><MapPin size={15} className="text-green-leaf" /> Kigali, Rwanda</div>
              <div className="flex items-center gap-2"><Phone size={15} className="text-green-leaf" /> +250 788 000 000</div>
              <div className="flex items-center gap-2"><Mail size={15} className="text-green-leaf" /> hello@liferootsschools.com</div>
            </div>
            <form
              onSubmit={(e) => { e.preventDefault(); }}
              className="mt-6 flex max-w-sm items-center gap-2 rounded-full bg-cream/10 p-1.5 ring-1 ring-cream/15"
            >
              <input type="email" placeholder="Newsletter email" className="w-full bg-transparent px-3 py-2 text-sm outline-none placeholder:text-cream/50" />
              <button type="submit" className="inline-flex items-center gap-1.5 rounded-full bg-green px-4 py-2 text-sm font-semibold text-cream">
                <Send size={14} /> Join
              </button>
            </form>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {COLS.map((c) => (
              <div key={c.heading}>
                <h4 className="font-display text-sm font-bold uppercase tracking-wider text-cream">{c.heading}</h4>
                <ul className="mt-4 space-y-3">
                  {c.links.map((l) => (
                    <li key={l.to}>
                      <Link to={l.to} className="text-sm text-cream/80 hover:text-cream underline-grow">{l.label}</Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-3 border-t border-cream/10 pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-cream/60">© {new Date().getFullYear()} Life Roots Schools. All rights reserved.</p>
          <p className="text-xs text-cream/60">Built in Christ. Rooted in Purpose. Prepared for the Future.</p>
        </div>
      </div>
    </footer>
  );
}
