import { useEffect, useRef, useState, type ReactNode } from "react";

export const IMG = "https://liferootsschools.com/wp-content/uploads";

export const IMAGES = {
  heroA: `${IMG}/2024/11/Slider-1-home.jpg`,
  heroB: `${IMG}/2024/12/LRS-end-of-term-2024-presendation-6.jpg`,
  heroC: `${IMG}/2024/12/LRS-preschool-graduation-2024-6.jpg`,
  general1: `${IMG}/2024/11/lrs-general-1.jpg`,
  general5: `${IMG}/2024/11/lrs-general-5.jpg`,
  general10: `${IMG}/2024/11/lrs-general-10.jpg`,
  general15: `${IMG}/2024/11/lrs-general-15.jpg`,
  general20: `${IMG}/2024/11/lrs-general-20.jpg`,
  general25: `${IMG}/2024/11/lrs-general-25.jpg`,
  general29: `${IMG}/2024/11/lrs-general-29.jpg`,
  general30: `${IMG}/2024/11/lrs-general-30.jpg`,
  general33: `${IMG}/2024/11/lrs-general-33.jpg`,
  general34: `${IMG}/2024/11/lrs-general-34.jpg`,
  general35: `${IMG}/2024/11/lrs-general-35.jpg`,
  lifepac: `${IMG}/2024/11/LIFEPAC-home-.jpg`,
  sevenstar: `${IMG}/2024/11/SevenStar-Online-Academyhome.jpg`,
  presentation: `${IMG}/2024/12/LRS-end-of-term-2024-presendation-6.jpg`,
  preschoolGrad: `${IMG}/2024/12/LRS-preschool-graduation-2024-6.jpg`,
  logo: `${IMG}/2024/01/lrs-logo-primary-01.png`,
  accredited: `${IMG}/2025/01/US-ACCREDITED-300x89.png`,
  stacked: `${IMG}/2024/11/Stacked-Full-Color-300-DPI.png`,
};

// Age-matched program imagery (best-fit from available site photos)
// Admins can later replace any of these via the Gallery.
export const PROGRAM_IMAGES = {
  preschool: IMAGES.preschoolGrad,      // little ones in cap & gown
  elementary: IMAGES.general33,         // younger primary kids
  middleSchool: IMAGES.general29,       // middle-grade students
  highSchool: IMAGES.presentation,      // older students at end-of-term presentation
};

export function useInView<T extends HTMLElement>(threshold = 0.2) {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (!ref.current || seen) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setSeen(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, [seen, threshold]);
  return { ref, seen };
}

export function Counter({ to, suffix = "", duration = 1800 }: { to: number; suffix?: string; duration?: number }) {
  const { ref, seen } = useInView<HTMLSpanElement>(0.4);
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!seen) return;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.floor(eased * to));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [seen, to, duration]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

export function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  const { ref, seen } = useInView<HTMLDivElement>(0.15);
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: seen ? 1 : 0,
        transform: seen ? "translateY(0)" : "translateY(28px)",
        transition: `opacity .8s cubic-bezier(.2,.7,.2,1) ${delay}ms, transform .8s cubic-bezier(.2,.7,.2,1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}
