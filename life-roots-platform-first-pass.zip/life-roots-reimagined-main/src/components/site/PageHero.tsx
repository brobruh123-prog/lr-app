import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

export function PageHero({
  eyebrow,
  title,
  subtitle,
  breadcrumb = [],
  image,
  children,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  breadcrumb?: Array<{ label: string; to?: string }>;
  image?: string;
  children?: ReactNode;
}) {
  return (
    <section className="relative isolate overflow-hidden gradient-hero text-cream pt-32 pb-20 sm:pt-40 sm:pb-28">
      {image && (
        <div className="absolute inset-0 -z-10">
          <img src={image} alt="" className="h-full w-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-b from-navy/70 via-navy/60 to-navy" />
        </div>
      )}
      <div className="container-app">
        {breadcrumb.length > 0 && (
          <nav className="flex flex-wrap items-center gap-1.5 text-xs text-cream/70">
            <Link to="/" className="hover:text-cream">Home</Link>
            {breadcrumb.map((b, i) => (
              <span key={i} className="flex items-center gap-1.5">
                <ChevronRight size={12} className="text-green-leaf" />
                {b.to ? <Link to={b.to} className="hover:text-cream">{b.label}</Link> : <span className="text-cream/90">{b.label}</span>}
              </span>
            ))}
          </nav>
        )}
        {eyebrow && (
          <p className="mt-6 inline-flex items-center gap-2 rounded-full border border-cream/15 bg-cream/5 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-green-leaf">
            {eyebrow}
          </p>
        )}
        <h1 className="mt-4 max-w-4xl font-display text-4xl font-bold leading-[1.05] text-balance sm:text-6xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-5 max-w-2xl text-lg text-cream/80 sm:text-xl">{subtitle}</p>
        )}
        {children && <div className="mt-8">{children}</div>}
      </div>
    </section>
  );
}
