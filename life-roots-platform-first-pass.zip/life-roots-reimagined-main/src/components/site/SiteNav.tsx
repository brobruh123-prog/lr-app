
import { Link } from "@tanstack/react-router";

export function SiteNav() {
  return (
    <header className="p-4 border-b">
      <div className="container-app flex justify-between items-center">
        <Link to="/" className="font-bold">LifeRoots Platform</Link>
        <nav className="flex gap-4">
          <Link to="/auth">Login</Link>
          <Link to="/gallery">Gallery</Link>
          <Link to="/assistant">AI Assistant</Link>
        </nav>
      </div>
    </header>
  );
}
