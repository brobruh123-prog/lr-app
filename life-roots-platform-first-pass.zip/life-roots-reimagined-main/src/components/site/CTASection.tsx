import { Link } from "@tanstack/react-router";
import { ArrowRight, Calendar } from "lucide-react";

export function CTASection({
  title = "Ready to take the next step?",
  description = "Visit our Kigali campus, meet our team, and see Life Roots Schools in action.",
}: { title?: string; description?: string }) {
  return (
    <section className="container-app py-20 sm:py-28">
      <div className="relative overflow-hidden rounded-[2rem] bg-navy p-10 text-cream shadow-elegant sm:p-16">
        <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-green/30 blur-3xl" />
        <div className="absolute -bottom-24 -left-10 h-72 w-72 rounded-full bg-green-leaf/20 blur-3xl" />
        <div className="relative grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="font-display text-3xl font-bold sm:text-4xl text-balance">{title}</h2>
            <p className="mt-4 max-w-md text-cream/80">{description}</p>
          </div>
          <div className="flex flex-wrap gap-3 lg:justify-end">
            <Link to="/admissions/apply" className="group inline-flex items-center gap-2 rounded-full bg-green px-6 py-3 text-sm font-semibold text-cream shadow-green transition hover:bg-green-soft">
              Apply Now <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
            </Link>
            <Link to="/admissions/visit" className="inline-flex items-center gap-2 rounded-full border border-cream/30 px-6 py-3 text-sm font-semibold text-cream hover:bg-cream/10">
              <Calendar size={15} /> Book a visit
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
