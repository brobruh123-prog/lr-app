import { useState, type FormEvent } from "react";
import { Send, Check } from "lucide-react";

export function ContactForm({
  title = "Send us a message",
  fields = "full",
  submitLabel = "Send message",
}: { title?: string; fields?: "full" | "visit" | "apply"; submitLabel?: string }) {
  const [sent, setSent] = useState(false);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  if (sent) {
    return (
      <div className="rounded-3xl border border-green/30 bg-green/5 p-8 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-green text-cream">
          <Check size={24} />
        </div>
        <h3 className="mt-4 font-display text-2xl font-bold text-navy">Message received</h3>
        <p className="mt-2 text-sm text-navy/70">Thank you — our admissions team will reach out within 1–2 business days.</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-3xl border border-navy/10 bg-white p-6 shadow-soft sm:p-8">
      <h3 className="font-display text-xl font-bold text-navy">{title}</h3>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Parent / Guardian name" name="name" required />
        <Field label="Email" name="email" type="email" required />
        <Field label="Phone" name="phone" type="tel" />
        {fields !== "visit" && <Field label="Student name" name="student" required />}
        {fields === "apply" && (
          <>
            <Field label="Date of birth" name="dob" type="date" />
            <SelectField label="Applying for grade" name="grade" options={[
              "Preschool","Kindergarten","Grade 1","Grade 2","Grade 3","Grade 4","Grade 5",
              "Grade 6","Grade 7","Grade 8","Grade 9","Grade 10","Grade 11","Grade 12",
            ]} />
          </>
        )}
        {fields === "visit" && (
          <Field label="Preferred visit date" name="visit-date" type="date" />
        )}
      </div>
      <div className="mt-4">
        <label className="block">
          <span className="block text-xs font-semibold uppercase tracking-wider text-navy/60">Message</span>
          <textarea name="message" rows={4} className="mt-1.5 w-full rounded-xl border border-navy/15 bg-cream/40 px-3 py-2.5 text-sm outline-none focus:border-green focus:bg-white" />
        </label>
      </div>
      <button type="submit" className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-green py-3 text-sm font-semibold text-cream hover:bg-green-soft sm:w-auto sm:px-8">
        <Send size={15} /> {submitLabel}
      </button>
    </form>
  );
}

function Field({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <label className="block">
      <span className="block text-xs font-semibold uppercase tracking-wider text-navy/60">{label}{required && " *"}</span>
      <input name={name} type={type} required={required} className="mt-1.5 w-full rounded-xl border border-navy/15 bg-cream/40 px-3 py-2.5 text-sm outline-none focus:border-green focus:bg-white" />
    </label>
  );
}

function SelectField({ label, name, options }: { label: string; name: string; options: string[] }) {
  return (
    <label className="block">
      <span className="block text-xs font-semibold uppercase tracking-wider text-navy/60">{label}</span>
      <select name={name} className="mt-1.5 w-full rounded-xl border border-navy/15 bg-cream/40 px-3 py-2.5 text-sm outline-none focus:border-green focus:bg-white">
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </label>
  );
}
