import { Panel } from "@/components/app/AppShell";

const STATUS_TONE: Record<string, string> = {
  present: "bg-green/20 text-green-900 dark:text-green",
  tardy: "bg-yellow-500/20 text-yellow-900 dark:text-yellow-300",
  excused: "bg-navy/10 text-navy/80 dark:text-cream/80",
  absent: "bg-rose-500/20 text-rose-900 dark:text-rose-300",
};

export function LifepacList({ lifepacs }: { lifepacs: any[] }) {
  if (!lifepacs.length) return <p className="text-sm text-navy/60 dark:text-cream/60">No LIFEPAC units assigned yet.</p>;
  const bySubject = lifepacs.reduce((acc: Record<string, any[]>, l) => {
    const k = l.subjects?.name ?? "Subject";
    (acc[k] ??= []).push(l); return acc;
  }, {});
  return (
    <div className="space-y-5">
      {Object.entries(bySubject).map(([subject, units]) => (
        <div key={subject}>
          <div className="mb-2 text-sm font-semibold text-navy dark:text-cream">{subject}</div>
          <div className="grid gap-3 sm:grid-cols-2">
            {units.map((u) => (
              <div key={u.id} className="rounded-xl border border-navy/10 p-4 dark:border-cream/10">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-navy dark:text-cream">Unit {u.unit_number} · {u.title}</div>
                  <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${u.status === "completed" ? "bg-green/20 text-green-900 dark:text-green" : u.status === "in_progress" ? "bg-yellow-500/20 text-yellow-900 dark:text-yellow-300" : "bg-navy/10 text-navy/70 dark:bg-cream/10 dark:text-cream/70"}`}>
                    {u.status.replace("_", " ")}
                  </span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-navy/10 dark:bg-cream/10">
                  <div className="h-2 rounded-full bg-green" style={{ width: `${u.progress_percent}%` }} />
                </div>
                <div className="mt-1 text-xs text-navy/60 dark:text-cream/60">{u.progress_percent}% complete</div>
                {u.teacher_comment && <p className="mt-2 text-xs italic text-navy/70 dark:text-cream/70">"{u.teacher_comment}"</p>}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export function GradesTable({ grades }: { grades: any[] }) {
  if (!grades.length) return <p className="text-sm text-navy/60 dark:text-cream/60">No grades recorded yet.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-xs uppercase tracking-wider text-navy/60 dark:text-cream/60">
          <tr><th className="py-2">Date</th><th>Subject</th><th>Type</th><th>Title</th><th className="text-right">Score</th><th className="text-right pl-4">%</th></tr>
        </thead>
        <tbody>
          {grades.map((g) => {
            const pct = Math.round((Number(g.score) / Number(g.max_score)) * 100);
            return (
              <tr key={g.id} className="border-t border-navy/10 dark:border-cream/10">
                <td className="py-2 text-navy/70 dark:text-cream/70">{g.recorded_at}</td>
                <td className="text-navy dark:text-cream">{g.subjects?.name}</td>
                <td><span className="rounded-full bg-navy/5 px-2 py-0.5 text-xs capitalize text-navy/70 dark:bg-cream/10 dark:text-cream/70">{g.category}</span></td>
                <td className="text-navy/80 dark:text-cream/80">{g.title}</td>
                <td className="text-right text-navy dark:text-cream">{g.score}/{g.max_score}</td>
                <td className={`text-right pl-4 font-semibold ${pct >= 80 ? "text-green" : pct >= 70 ? "text-yellow-600" : "text-rose-600"}`}>{pct}%</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function AttendanceList({ attendance }: { attendance: any[] }) {
  if (!attendance.length) return <p className="text-sm text-navy/60 dark:text-cream/60">No attendance records.</p>;
  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
      {attendance.map((a) => (
        <div key={a.id} className="flex items-center justify-between rounded-xl border border-navy/10 px-3 py-2 dark:border-cream/10">
          <span className="text-sm text-navy/80 dark:text-cream/80">{a.date}</span>
          <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${STATUS_TONE[a.status] ?? "bg-navy/10"}`}>{a.status}</span>
        </div>
      ))}
    </div>
  );
}

export function SubjectAverages({ subjects, averages }: { subjects: any[]; averages: Record<string, number | null> }) {
  return (
    <Panel title="Subject Averages">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {subjects.map((s) => {
          const v = averages[s.code];
          return (
            <div key={s.id} className="rounded-xl bg-navy/5 p-3 dark:bg-cream/5">
              <div className="text-xs uppercase tracking-wider text-navy/60 dark:text-cream/60">{s.name}</div>
              <div className="mt-1 font-display text-2xl font-bold text-navy dark:text-cream">{v != null ? `${v}%` : "—"}</div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}
