import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  LayoutDashboard, BookOpen, LogOut, Menu, X, Sprout,
  Image as ImageIcon, FileText, ClipboardList,
} from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import type { Role } from "@/lib/dashboard.functions";

type NavItem = { label: string; to: string; icon: React.ComponentType<{ size?: number }> };

const NAV_BY_ROLE: Record<Exclude<Role, null>, NavItem[]> = {
  admin: [
    { label: "Overview", to: "/app/admin", icon: LayoutDashboard },
    { label: "Gallery", to: "/admin/gallery", icon: ImageIcon },
  ],
  teacher: [
    { label: "Dashboard", to: "/app/teacher", icon: LayoutDashboard },
    { label: "Gradebook", to: "/app/teacher/gradebook", icon: ClipboardList },
    { label: "Attendance", to: "/app/teacher/attendance", icon: FileText },
  ],
  student: [
    { label: "Dashboard", to: "/app/student", icon: LayoutDashboard },
    { label: "LIFEPACs", to: "/app/student/lifepacs", icon: BookOpen },
    { label: "Grades", to: "/app/student/grades", icon: ClipboardList },
    { label: "Attendance", to: "/app/student/attendance", icon: FileText },
  ],
  parent: [
    { label: "Dashboard", to: "/app/parent", icon: LayoutDashboard },
  ],
};


export function AppShell({
  role,
  fullName,
  email,
  children,
}: {
  role: Exclude<Role, null>;
  fullName: string | null;
  email: string | null;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const nav = NAV_BY_ROLE[role];

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <div className="min-h-screen bg-cream/60 dark:bg-navy">
      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-navy/10 bg-cream px-4 py-3 lg:hidden dark:bg-navy dark:border-cream/10">
        <button onClick={() => setOpen(true)} aria-label="Open menu" className="grid h-10 w-10 place-items-center rounded-full bg-navy text-cream">
          <Menu size={18} />
        </button>
        <Link to="/" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-green text-cream"><Sprout size={16} /></span>
          <span className="font-display text-base font-bold text-navy dark:text-cream">Liferoots</span>
        </Link>
        <button onClick={() => setDark((d) => !d)} aria-label="Toggle theme" className="text-sm text-navy/70 dark:text-cream/70">{dark ? "☀" : "🌙"}</button>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-40 w-72 transform border-r border-navy/10 bg-cream p-5 transition-transform lg:relative lg:translate-x-0 dark:bg-navy/90 dark:border-cream/10 ${
            open ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-green text-cream"><Sprout size={18} /></span>
              <span className="font-display text-lg font-bold text-navy dark:text-cream">Liferoots</span>
            </Link>
            <button onClick={() => setOpen(false)} className="lg:hidden text-navy dark:text-cream"><X size={20} /></button>
          </div>

          <div className="mt-2 text-xs uppercase tracking-wider text-navy/50 dark:text-cream/50">{role} portal</div>

          <nav className="mt-6 flex flex-col gap-1">
            {nav.map((item, i) => {
              const active = pathname === item.to;
              const Icon = item.icon;

              return (
                <Link
                  key={i}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                    active
                      ? "bg-green text-cream shadow-green"
                      : "text-navy/80 hover:bg-navy/5 dark:text-cream/80 dark:hover:bg-cream/5"
                  }`}
                >
                  <Icon size={18} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="absolute inset-x-5 bottom-5">
            <div className="rounded-2xl bg-navy/5 p-4 dark:bg-cream/5">
              <div className="truncate text-sm font-semibold text-navy dark:text-cream">{fullName ?? "Account"}</div>
              <div className="truncate text-xs text-navy/60 dark:text-cream/60">{email}</div>
              <button
                onClick={signOut}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-navy px-4 py-2 text-xs font-semibold text-cream hover:bg-navy/90"
              >
                <LogOut size={14} /> Sign out
              </button>
            </div>
          </div>
        </aside>

        {open && <div onClick={() => setOpen(false)} className="fixed inset-0 z-30 bg-navy/50 lg:hidden" />}

        {/* Main */}
        <main className="min-h-screen flex-1 p-4 sm:p-6 lg:p-10">{children}</main>
      </div>
    </div>
  );
}

export function StatCard({ label, value, hint, accent = "bg-green" }: { label: string; value: string | number; hint?: string; accent?: string }) {
  return (
    <div className="rounded-2xl bg-white p-5 shadow-soft dark:bg-navy/60">
      <div className={`h-1 w-10 rounded-full ${accent} mb-3`} />
      <div className="text-xs uppercase tracking-wider text-navy/60 dark:text-cream/60">{label}</div>
      <div className="mt-1 font-display text-3xl font-bold text-navy dark:text-cream">{value}</div>
      {hint && <div className="mt-1 text-xs text-navy/50 dark:text-cream/50">{hint}</div>}
    </div>
  );
}

export function Panel({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-white p-6 shadow-soft dark:bg-navy/60">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display text-lg font-bold text-navy dark:text-cream">{title}</h2>
        {action}
      </div>
      {children}
    </div>
  );
}
