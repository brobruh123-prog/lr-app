import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { IMAGES, Reveal } from "@/components/site/shared";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Life Roots Schools" },
      { name: "description", content: "Photos from life at Life Roots Schools — classrooms, chapel, sports, graduations, and everyday joy in Kigali, Rwanda." },
      { property: "og:title", content: "Life Roots Schools Gallery" },
      { property: "og:description", content: "Moments from our campus and community." },
      { property: "og:image", content: IMAGES.heroA },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  component: GalleryPage,
});

type Photo = {
  id: string;
  image_path: string;
  caption: string | null;
  category: string;
  url: string;
};

const CATEGORIES = ["all", "preschool", "elementary", "middle-school", "high-school", "campus", "events", "general"] as const;

function GalleryPage() {
  const [photos, setPhotos] = useState<Photo[] | null>(null);
  const [filter, setFilter] = useState<string>("all");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data, error } = await supabase
        .from("gallery_photos")
        .select("id, image_path, caption, category")
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: false });
      if (error) {
        if (active) setError(error.message);
        return;
      }
      const paths = (data ?? []).map((p) => p.image_path);
      const signed = paths.length
        ? await supabase.storage.from("gallery").createSignedUrls(paths, 3600)
        : { data: [], error: null };
      const byPath = new Map<string, string>();
      (signed.data ?? []).forEach((s) => { if (s.path && s.signedUrl) byPath.set(s.path, s.signedUrl); });
      const enriched: Photo[] = (data ?? []).map((p) => ({
        ...p,
        url: byPath.get(p.image_path) ?? "",
      }));
      if (active) setPhotos(enriched);
    })();
    return () => { active = false; };
  }, []);

  const visible = (photos ?? []).filter((p) => filter === "all" || p.category === filter);

  return (
    <PageLayout>
      <PageHero
        eyebrow="Photos"
        title="Life at Life Roots"
        subtitle="A growing collection of moments from our campus, classrooms, chapel and community."
        image={IMAGES.heroA}
        breadcrumb={[{ label: "Gallery" }]}
      />

      <section className="container-app py-16">
        <div className="mb-8 flex flex-wrap items-center gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`rounded-full px-4 py-2 text-sm font-medium capitalize transition ${
                filter === c ? "bg-navy text-cream" : "bg-cream/80 text-navy/70 hover:bg-cream"
              }`}
            >
              {c.replace("-", " ")}
            </button>
          ))}
          <Link to="/auth" className="ml-auto text-sm text-navy/60 hover:text-navy">Staff sign in</Link>
        </div>

        {error && <p className="text-red-600">{error}</p>}

        {photos === null ? (
          <p className="text-navy/60">Loading photos…</p>
        ) : visible.length === 0 ? (
          <div className="rounded-3xl bg-cream/80 p-12 text-center">
            <p className="text-navy/70">No photos here yet. Check back soon — or, if you're staff, <Link to="/auth" className="font-semibold text-green underline">sign in to add some</Link>.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-4">
            {visible.map((p, i) => (
              <Reveal key={p.id} delay={(i % 8) * 40}>
                <figure className="group relative overflow-hidden rounded-2xl bg-navy/5">
                  <img
                    src={p.url}
                    alt={p.caption ?? "Life Roots Schools"}
                    loading="lazy"
                    className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {p.caption && (
                    <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-navy/90 to-transparent p-3 text-xs text-cream opacity-0 transition-opacity group-hover:opacity-100">
                      {p.caption}
                    </figcaption>
                  )}
                </figure>
              </Reveal>
            ))}
          </div>
        )}
      </section>
    </PageLayout>
  );
}
