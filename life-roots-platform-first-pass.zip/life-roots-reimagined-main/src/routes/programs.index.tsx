import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, PROGRAM_IMAGES, Reveal } from "@/components/site/shared";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/programs/")({
  head: () => ({
    meta: [
      { title: "Academic Programs — Life Roots Schools" },
      { name: "description", content: "Preschool through Grade 12 at Life Roots Schools in Kigali, Rwanda. Christ-centered, mastery-based learning at every stage." },
      { property: "og:title", content: "Academic Programs" },
      { property: "og:description", content: "From first steps to university — a journey built around your child." },
      { property: "og:image", content: PROGRAM_IMAGES.elementary },
      { property: "og:url", content: "/programs" },
    ],
    links: [{ rel: "canonical", href: "/programs" }],
  }),
  component: ProgramsPage,
});

const PROGRAMS = [
  { to: "/programs/preschool", tag: "Ages 3–5", title: "Preschool", body: "Joyful early learning that nurtures curiosity, language, and character through play and Scripture.", img: PROGRAM_IMAGES.preschool },
  { to: "/programs/elementary", tag: "Grades 1–5", title: "Elementary", body: "Strong foundations in literacy, numeracy, science, and biblical worldview through LIFEPAC.", img: PROGRAM_IMAGES.elementary },
  { to: "/programs/middle-school", tag: "Grades 6–8", title: "Middle School", body: "Critical thinking, ownership of learning, and identity formation in Christ.", img: PROGRAM_IMAGES.middleSchool },
  { to: "/programs/high-school", tag: "Grades 9–12", title: "High School", body: "Rigorous, university-ready academics with the Canadian Pathway Program (CPP).", img: PROGRAM_IMAGES.highSchool },
];

function ProgramsPage() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="Academics"
        breadcrumb={[{ label: "Programs" }]}
        title="Programs for every stage — Preschool to Grade 12."
        subtitle="Every Life Roots program combines the LIFEPAC mastery curriculum, Sevenstar online learning, and dedicated teacher mentorship — adapted to where each student is."
      />

      <section className="container-app py-20 sm:py-28">
        <div className="grid gap-8 md:grid-cols-2">
          {PROGRAMS.map((p, i) => (
            <Reveal key={p.to} delay={i * 80}>
              <Link to={p.to} className="block h-full">
                <article className="group relative h-full overflow-hidden rounded-3xl bg-navy text-cream shadow-soft transition-all hover:shadow-elegant">
                  <div className="relative h-64 overflow-hidden">
                    <img src={p.img} alt={p.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/30 to-transparent" />
                    <span className="absolute left-5 top-5 inline-flex items-center gap-1.5 rounded-full bg-cream/95 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-navy">
                      {p.tag}
                    </span>
                  </div>
                  <div className="p-8">
                    <h3 className="font-display text-3xl font-bold">{p.title}</h3>
                    <p className="mt-3 text-cream/75">{p.body}</p>
                    <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-green-leaf">
                      Explore {p.title} <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </article>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      <CTASection title="Find the right fit for your child" description="Speak with our admissions team — we'll walk you through the program that fits your child's age, goals, and learning style." />
    </PageLayout>
  );
}
