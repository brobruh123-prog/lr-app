import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { Check, Laptop, Wifi, Users } from "lucide-react";

export const Route = createFileRoute("/curriculum/sevenstar")({
  head: () => ({
    meta: [
      { title: "Sevenstar Online Academy — Life Roots Schools" },
      { name: "description", content: "Christian online courses through Sevenstar Online Academy — credentialed teachers, AP options, and rich electives at Life Roots Schools." },
      { property: "og:title", content: "Sevenstar at Life Roots" },
      { property: "og:description", content: "World-class Christian online courses paired with on-campus mentorship." },
      { property: "og:image", content: IMAGES.sevenstar },
      { property: "og:url", content: "/curriculum/sevenstar" },
    ],
    links: [{ rel: "canonical", href: "/curriculum/sevenstar" }],
  }),
  component: SevenstarPage,
});

function SevenstarPage() {
  const features = [
    "Hundreds of courses across core and elective subjects",
    "Credentialed Christian teachers from around the world",
    "AP, honours, and college-prep options for high school",
    "Flexible scheduling that fits our on-campus rhythm",
    "Real-time progress tracking for students, parents, and mentors",
    "Tech-rich learning — coding, design, world languages, and more",
  ];
  const categories = ["English & Lit", "Mathematics", "Science", "Bible & Theology", "World Languages", "Computer Science", "Business", "Fine Arts", "AP Courses"];
  const requirements = [
    { icon: Laptop, t: "Device", d: "A reliable laptop (provided by school during class hours)" },
    { icon: Wifi, t: "Connectivity", d: "Fast campus Wi-Fi during all online learning blocks" },
    { icon: Users, t: "Mentorship", d: "On-campus mentor teacher present in every Sevenstar block" },
  ];

  return (
    <PageLayout>
      <PageHero
        eyebrow="Online Academy"
        breadcrumb={[{ label: "Curriculum", to: "/curriculum" }, { label: "Sevenstar" }]}
        title="Sevenstar Online Academy — world-class courses, fully integrated."
        subtitle="A best-in-class Christian online program that gives our students access to advanced and elective courses while staying on campus with their mentors."
        image={IMAGES.sevenstar}
      />

      <section className="container-app py-20">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">The best of both worlds</h2></Reveal>
            <Reveal delay={80}>
              <p className="mt-5 text-navy/75">
                Online learning expands what we can offer — but our students are never alone. Sevenstar courses run during scheduled blocks on campus, supervised by on-site mentor teachers who know each student personally.
              </p>
            </Reveal>
            <ul className="mt-8 space-y-3">
              {features.map((f, i) => (
                <Reveal key={f} delay={i * 50}>
                  <li className="flex items-start gap-3 rounded-xl border border-navy/10 bg-white px-4 py-3">
                    <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-green text-cream"><Check size={12} /></span>
                    <span className="text-sm text-navy">{f}</span>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>
          <Reveal>
            <img src={IMAGES.sevenstar} alt="Sevenstar" className="rounded-[2rem] shadow-elegant" />
          </Reveal>
        </div>
      </section>

      <section className="bg-beige/60 py-20">
        <div className="container-app">
          <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Course categories</h2></Reveal>
          <div className="mt-8 flex flex-wrap gap-3">
            {categories.map((c) => (
              <span key={c} className="rounded-full border border-navy/15 bg-white px-5 py-2 font-medium text-navy">{c}</span>
            ))}
          </div>

          <h3 className="mt-14 font-display text-2xl font-bold text-navy">What students need</h3>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            {requirements.map((r) => (
              <article key={r.t} className="rounded-3xl border border-navy/10 bg-white p-6 shadow-soft">
                <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-navy text-cream"><r.icon size={20} /></span>
                <h4 className="mt-5 font-display text-lg font-bold text-navy">{r.t}</h4>
                <p className="mt-2 text-sm text-navy/70">{r.d}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
