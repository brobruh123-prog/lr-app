import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getMyChildren, getStudentSnapshot } from "@/lib/academics.functions";
import { getAnnouncements } from "@/lib/dashboard.functions";
import { StatCard, Panel } from "@/components/app/AppShell";
import { LifepacList, GradesTable, AttendanceList, SubjectAverages } from "@/components/app/AcademicViews";

export const Route = createFileRoute("/app/parent")({
  ssr: false,
  component: ParentDashboard,
});

function ParentDashboard() {
  const fetchChildren = useServerFn(getMyChildren);
  const fetchSnap = useServerFn(getStudentSnapshot);
  const fetchAnn = useServerFn(getAnnouncements);
  const [children, setChildren] = useState<any[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [snap, setSnap] = useState<any>(null);
  const [ann, setAnn] = useState<any[]>([]);

  useEffect(() => {
    fetchChildren({ data: undefined }).then((c) => {
      setChildren(c);
      if (c[0]) setSelected(c[0].id);
    }).catch(() => {});
    fetchAnn({ data: undefined }).then(setAnn).catch(() => {});
  }, [fetchChildren, fetchAnn]);

  useEffect(() => {
    if (!selected) return;
    fetchSnap({ data: { studentId: selected } }).then(setSnap).catch(() => {});
  }, [selected, fetchSnap]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">Parent Dashboard</h1>
          <p className="mt-1 text-navy/60 dark:text-cream/60">Stay connected with your children's school journey.</p>
        </div>
        {children.length > 1 && (
          <select
            value={selected ?? ""}
            onChange={(e) => setSelected(e.target.value)}
            className="rounded-full border border-navy/15 bg-white px-4 py-2 text-sm text-navy dark:bg-navy/60 dark:text-cream"
          >
            {children.map((c) => <option key={c.id} value={c.id}>{c.full_name} — {c.grade_level}</option>)}
          </select>
        )}
      </div>

      {children.length === 0 ? (
        <Panel title="No children linked">
          <p className="text-sm text-navy/60 dark:text-cream/60">Ask your school admin to link your account to your child(ren).</p>
        </Panel>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Child" value={snap?.student?.full_name?.split(" ")[0] ?? "—"} hint={snap?.student?.grade_level} accent="bg-green" />
            <StatCard label="GPA" value={snap?.gpa != null ? snap.gpa.toFixed(2) : "—"} accent="bg-navy" />
            <StatCard label="Attendance" value={snap?.attendanceRate != null ? `${snap.attendanceRate}%` : "—"} accent="bg-yellow-500" />
            <StatCard label="Pending LIFEPACs" value={snap?.lifepacs?.filter((l: any) => l.status !== "completed").length ?? 0} accent="bg-rose-500" />
          </div>

          {snap?.subjects && <SubjectAverages subjects={snap.subjects} averages={snap.averages} />}

          <div className="grid gap-6 lg:grid-cols-2">
            <Panel title="Recent Grades"><GradesTable grades={(snap?.grades ?? []).slice(0, 10)} /></Panel>
            <Panel title="Recent Attendance"><AttendanceList attendance={(snap?.attendance ?? []).slice(0, 15)} /></Panel>
          </div>
          <Panel title="LIFEPAC Progress"><LifepacList lifepacs={snap?.lifepacs ?? []} /></Panel>
        </>
      )}

      <Panel title="School Announcements">
        {ann.length ? (
          <ul className="space-y-3">
            {ann.map((a) => (
              <li key={a.id} className="rounded-xl border border-navy/10 p-4 dark:border-cream/10">
                <h3 className="font-semibold text-navy dark:text-cream">{a.title}</h3>
                <p className="mt-1 text-sm text-navy/70 dark:text-cream/70">{a.body}</p>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-navy/60 dark:text-cream/60">No announcements.</p>}
      </Panel>
    </div>
  );
}
