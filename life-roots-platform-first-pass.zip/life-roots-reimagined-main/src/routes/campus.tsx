import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { ArrowRight, Building2, Calendar, Clock, MapPin, Phone } from "lucide-react";

export const Route = createFileRoute("/campus")({
  head: () => ({
    meta: [
      { title: "Our Kigali Campus — Life Roots Schools" },
      { name: "description", content: "Visit our Christ-centered campus in Kigali, Rwanda — modern classrooms, science labs, sports facilities, and a vibrant learning community." },
      { property: "og:title", content: "Kigali Campus — Life Roots" },
      { property: "og:description", content: "A home in the heart of Kigali, Rwanda." },
      { property: "og:image", content: IMAGES.heroA },
      { property: "og:url", content: "/campus" },
    ],
    links: [{ rel: "canonical", href: "/campus" }],
  }),
  component: CampusPage,
});

function CampusPage() {
  const facilities = [
    "Bright, modern classrooms",
    "Science & STEM lab",
    "Computer & coding lab",
    "Library & reading nook",
    "Chapel & worship space",
    "Outdoor sports field",
    "Indoor multi-purpose hall",
    "Dedicated art & music studio",
    "Safe drop-off & pickup zones",
  ];
  const gallery = [IMAGES.heroA, IMAGES.general29, IMAGES.general35, IMAGES.presentation, IMAGES.preschoolGrad, IMAGES.lifepac];

  return (
    <PageLayout>
      <PageHero
        eyebrow="Our Campus"
        breadcrumb={[{ label: "Campus" }]}
        title="A home in the heart of Kigali."
        subtitle="A vibrant Christ-centered campus with everything our students need to learn, worship, play, and grow."
        image={IMAGES.heroA}
      />

      <section className="container-app py-20">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr] lg:items-start">
          <Reveal>
            <img src={IMAGES.heroA} alt="Life Roots Kigali" className="rounded-[2rem] shadow-elegant" />
          </Reveal>
          <div className="space-y-6">
            <div className="rounded-3xl border border-navy/10 bg-white p-7 shadow-soft">
              <div className="inline-flex items-center gap-2 rounded-full bg-green/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-green">
                <Building2 size={12} /> Kigali, Rwanda
              </div>
              <h2 className="mt-4 font-display text-2xl font-bold text-navy">Visit us</h2>
              <ul className="mt-5 space-y-3 text-sm">
                <li className="flex items-start gap-3"><MapPin size={16} className="mt-0.5 text-green" /><span className="text-navy/80">Kigali, Rwanda</span></li>
                <li className="flex items-start gap-3"><Phone size={16} className="mt-0.5 text-green" /><span className="text-navy/80">+250 788 000 000</span></li>
                <li className="flex items-start gap-3"><Clock size={16} className="mt-0.5 text-green" /><span className="text-navy/80">Mon–Fri · 7:30 AM – 4:00 PM</span></li>
                <li className="flex items-start gap-3"><Calendar size={16} className="mt-0.5 text-green" /><span className="text-navy/80">Tours by appointment</span></li>
              </ul>
              <div className="mt-6 flex flex-col gap-2">
                <Link to="/admissions/visit" className="inline-flex items-center justify-center gap-2 rounded-full bg-green px-5 py-2.5 text-sm font-semibold text-cream hover:bg-green-soft">
                  Book a tour <ArrowRight size={14} />
                </Link>
                <Link to="/contact" className="inline-flex items-center justify-center gap-2 rounded-full border border-navy/15 px-5 py-2.5 text-sm font-semibold text-navy hover:bg-navy hover:text-cream">
                  Contact us
                </Link>
              </div>
            </div>

            <div className="aspect-[4/3] overflow-hidden rounded-3xl border border-navy/10 bg-navy/5">
              <iframe
                title="Kigali map"
                src="https://www.openstreetmap.org/export/embed.html?bbox=30.04%2C-1.97%2C30.12%2C-1.93&layer=mapnik"
                className="h-full w-full"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="bg-beige/60 py-20">
        <div className="container-app">
          <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Facilities</h2></Reveal>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {facilities.map((f, i) => (
              <Reveal key={f} delay={i * 30}>
                <div className="rounded-xl border border-navy/10 bg-white px-5 py-4 text-sm font-medium text-navy">{f}</div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="container-app py-20">
        <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Campus gallery</h2></Reveal>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {gallery.map((src, i) => (
            <Reveal key={src} delay={i * 40}>
              <div className="overflow-hidden rounded-3xl shadow-soft">
                <img src={src} alt={`Campus ${i + 1}`} className="h-72 w-full object-cover transition-transform duration-700 hover:scale-105" />
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
