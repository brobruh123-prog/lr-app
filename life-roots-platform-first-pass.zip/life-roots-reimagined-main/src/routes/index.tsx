
import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <PageLayout>
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-3xl px-6">
          <h1 className="text-5xl font-bold mb-6">LifeRoots School Platform</h1>
          <p className="mb-8 text-lg">
            Access your school services, gallery and AI assistant.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/auth" className="rounded px-6 py-3 border">Sign In</Link>
            <Link to="/gallery" className="rounded px-6 py-3 border">Gallery</Link>
            <Link to="/assistant" className="rounded px-6 py-3 border">AI Assistant</Link>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}
