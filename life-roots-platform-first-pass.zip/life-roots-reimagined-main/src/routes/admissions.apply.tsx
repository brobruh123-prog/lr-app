import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { ContactForm } from "@/components/site/ContactForm";

export const Route = createFileRoute("/admissions/apply")({
  head: () => ({
    meta: [
      { title: "Apply Now — Life Roots Schools" },
      { name: "description", content: "Start your application to Life Roots Schools in Kigali, Rwanda." },
      { property: "og:title", content: "Apply to Life Roots" },
      { property: "og:description", content: "Begin your child's Life Roots journey today." },
      { property: "og:url", content: "/admissions/apply" },
    ],
    links: [{ rel: "canonical", href: "/admissions/apply" }],
  }),
  component: ApplyPage,
});

function ApplyPage() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="Start your application"
        breadcrumb={[{ label: "Admissions", to: "/admissions" }, { label: "Apply" }]}
        title="Apply to Life Roots Schools."
        subtitle="Tell us about your child. We'll get back to you within one to two business days with next steps."
      />
      <section className="container-app py-20">
        <div className="mx-auto max-w-2xl">
          <ContactForm title="Application — tell us about your family" fields="apply" submitLabel="Submit application" />
        </div>
      </section>
    </PageLayout>
  );
}
