import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { getTeacherWorkspace, recordAttendance } from "@/lib/academics.functions";
import { Panel } from "@/components/app/AppShell";

export const Route = createFileRoute("/app/teacher/attendance")({
  ssr: false,
  component: AttendanceEntry,
});

const STATUSES = ["present", "tardy", "excused", "absent"] as const;
type Status = (typeof STATUSES)[number];

function AttendanceEntry() {
  const fetchWs = useServerFn(getTeacherWorkspace);
  const submit = useServerFn(recordAttendance);
  const [ws, setWs] = useState<any>(null);
  const [classId, setClassId] = useState<string>("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [marks, setMarks] = useState<Record<string, Status>>({});
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => { fetchWs({ data: undefined }).then(setWs).catch(() => {}); }, [fetchWs]);

  const roster = useMemo(
    () => (ws?.students ?? []).filter((s: any) => !classId || s.class_id === classId),
    [ws, classId],
  );

  async function onSave() {
    setMsg(null);
    const entries = roster.map((s: any) => ({
      studentId: s.id, classId: s.class_id, date, status: marks[s.id] ?? "present",
    }));
    try {
      await submit({ data: { entries } });
      setMsg(`✓ Saved ${entries.length} records`);
    } catch (err: any) {
      setMsg("Error: " + (err.message ?? "failed"));
    }
  }

  function setAll(s: Status) {
    const m: Record<string, Status> = {};
    roster.forEach((st: any) => (m[st.id] = s));
    setMarks(m);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">Attendance</h1>
        <p className="mt-1 text-navy/60 dark:text-cream/60">Mark today's attendance for a class.</p>
      </div>
      <Panel title="Class & Date">
        <div className="grid gap-4 sm:grid-cols-3">
          <label className="block">
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-navy/60 dark:text-cream/60">Class</span>
            <select value={classId} onChange={(e) => setClassId(e.target.value)} className="w-full rounded-xl border border-navy/15 bg-white px-3 py-2 text-sm dark:bg-navy/60 dark:border-cream/15 dark:text-cream">
              <option value="">All students</option>
              {ws?.classes?.map((c: any) => <option key={c.id} value={c.id}>{c.name} — {c.grade_level}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-navy/60 dark:text-cream/60">Date</span>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-xl border border-navy/15 bg-white px-3 py-2 text-sm dark:bg-navy/60 dark:border-cream/15 dark:text-cream" />
          </label>
          <div className="flex items-end gap-2">
            <button onClick={() => setAll("present")} className="rounded-full bg-green/20 px-3 py-2 text-xs font-semibold text-green-900 dark:text-green">All Present</button>
            <button onClick={() => setMarks({})} className="rounded-full bg-navy/10 px-3 py-2 text-xs font-semibold text-navy/70 dark:bg-cream/10 dark:text-cream/70">Reset</button>
          </div>
        </div>
      </Panel>

      <Panel title={`Roster (${roster.length})`}>
        {roster.length === 0 ? (
          <p className="text-sm text-navy/60 dark:text-cream/60">No students.</p>
        ) : (
          <ul className="divide-y divide-navy/10 dark:divide-cream/10">
            {roster.map((s: any) => {
              const current = marks[s.id] ?? "present";
              return (
                <li key={s.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="font-semibold text-navy dark:text-cream">{s.full_name}</div>
                    <div className="text-xs text-navy/60 dark:text-cream/60">{s.grade_level}</div>
                  </div>
                  <div className="flex gap-1">
                    {STATUSES.map((st) => (
                      <button
                        key={st}
                        onClick={() => setMarks({ ...marks, [s.id]: st })}
                        className={`rounded-full px-3 py-1 text-xs font-semibold capitalize transition ${
                          current === st
                            ? st === "present" ? "bg-green text-cream"
                            : st === "tardy" ? "bg-yellow-500 text-cream"
                            : st === "excused" ? "bg-navy text-cream"
                            : "bg-rose-500 text-cream"
                            : "bg-navy/5 text-navy/60 dark:bg-cream/5 dark:text-cream/60"
                        }`}
                      >{st}</button>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        <div className="mt-4 flex items-center justify-between">
          {msg && <span className="text-sm text-navy/70 dark:text-cream/70">{msg}</span>}
          <button onClick={onSave} disabled={!roster.length} className="ml-auto rounded-full bg-green px-6 py-2 text-sm font-semibold text-cream shadow-green hover:bg-green/90 disabled:opacity-50">Save Attendance</button>
        </div>
      </Panel>
    </div>
  );
}
