import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getAnnouncements } from "@/lib/dashboard.functions";
import { getStudentSnapshot } from "@/lib/academics.functions";
import { StatCard, Panel } from "@/components/app/AppShell";
import { LifepacList, SubjectAverages } from "@/components/app/AcademicViews";

export const Route = createFileRoute("/app/student")({
  ssr: false,
  component: StudentDashboard,
});

function StudentDashboard() {
  const fetchAnn = useServerFn(getAnnouncements);
  const fetchSnap = useServerFn(getStudentSnapshot);
  const [ann, setAnn] = useState<any[]>([]);
  const [snap, setSnap] = useState<any>(null);

  useEffect(() => {
    fetchAnn({ data: undefined }).then(setAnn).catch(() => {});
    fetchSnap({ data: { studentId: null } }).then(setSnap).catch(() => {});
  }, [fetchAnn, fetchSnap]);

  const pending = snap?.lifepacs?.filter((l: any) => l.status !== "completed").length ?? 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">Welcome{snap?.student?.full_name ? `, ${snap.student.full_name.split(" ")[0]}` : ""} 👋</h1>
        <p className="mt-1 text-navy/60 dark:text-cream/60">Your academic snapshot for this term.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Current GPA" value={snap?.gpa != null ? snap.gpa.toFixed(2) : "—"} accent="bg-green" />
        <StatCard label="Attendance" value={snap?.attendanceRate != null ? `${snap.attendanceRate}%` : "—"} accent="bg-navy" />
        <StatCard label="Pending LIFEPACs" value={pending} accent="bg-yellow-500" />
        <StatCard label="Grades Recorded" value={snap?.grades?.length ?? 0} accent="bg-rose-500" />
      </div>

      {snap?.subjects && <SubjectAverages subjects={snap.subjects} averages={snap.averages} />}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Panel title="LIFEPAC Progress" action={<Link to="/app/student" className="text-xs font-semibold text-green hover:underline">Refresh</Link>}>
            <LifepacList lifepacs={snap?.lifepacs ?? []} />
          </Panel>
        </div>
        <Panel title="Announcements">
          {ann.length ? (
            <ul className="space-y-3">
              {ann.map((a) => (
                <li key={a.id} className="rounded-xl border border-navy/10 p-3 dark:border-cream/10">
                  <h3 className="text-sm font-semibold text-navy dark:text-cream">{a.title}</h3>
                  <p className="mt-1 text-xs text-navy/70 dark:text-cream/70">{a.body}</p>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-navy/60 dark:text-cream/60">No announcements.</p>}
        </Panel>
      </div>
    </div>
  );
}
