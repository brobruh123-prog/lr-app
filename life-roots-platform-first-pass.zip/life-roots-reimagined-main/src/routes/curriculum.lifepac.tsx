import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { Check } from "lucide-react";

export const Route = createFileRoute("/curriculum/lifepac")({
  head: () => ({
    meta: [
      { title: "LIFEPAC Curriculum — Life Roots Schools" },
      { name: "description", content: "LIFEPAC is the mastery-based, biblical-worldview core curriculum used at Life Roots Schools — self-paced and deeply personalised." },
      { property: "og:title", content: "LIFEPAC at Life Roots" },
      { property: "og:description", content: "Mastery-based learning with a biblical worldview, across every core subject." },
      { property: "og:image", content: IMAGES.lifepac },
      { property: "og:url", content: "/curriculum/lifepac" },
    ],
    links: [{ rel: "canonical", href: "/curriculum/lifepac" }],
  }),
  component: LifepacPage,
});

function LifepacPage() {
  const features = [
    "Mastery-based — students don't move on until they truly understand",
    "Self-paced — accelerate or take more time, as needed",
    "Biblical worldview integrated into every subject",
    "10 workbooks per subject, per grade — clear, bite-sized units",
    "Built-in diagnostic and self-tests after every section",
    "Used by Christian families and schools across the world",
  ];
  const subjects = ["Bible", "Mathematics", "Language Arts", "Science", "History & Geography", "Electives"];
  const steps = [
    { n: "01", t: "Diagnose", d: "A short placement assessment puts each student in the exact worktext that matches their level." },
    { n: "02", t: "Learn", d: "Students work through the LIFEPAC unit with teacher guidance, demonstrations, and group discussion." },
    { n: "03", t: "Practice", d: "Exercises and self-tests catch gaps before they become problems." },
    { n: "04", t: "Master", d: "An end-of-unit test confirms mastery — only then do they advance." },
  ];

  return (
    <PageLayout>
      <PageHero
        eyebrow="Mastery Curriculum"
        breadcrumb={[{ label: "Curriculum", to: "/curriculum" }, { label: "LIFEPAC" }]}
        title="LIFEPAC — mastery-based learning that meets every student where they are."
        subtitle="Our core academic curriculum: self-paced biblical worldview worktexts that build deep understanding, one mastered skill at a time."
        image={IMAGES.lifepac}
      />

      <section className="container-app py-20">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <Reveal>
            <img src={IMAGES.lifepac} alt="LIFEPAC" className="rounded-[2rem] shadow-elegant" />
          </Reveal>
          <div>
            <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Why we chose LIFEPAC</h2></Reveal>
            <Reveal delay={80}>
              <p className="mt-5 text-navy/75">
                Traditional classrooms move at the speed of the average. Some students fall behind, others coast. LIFEPAC was built to fix that — every student learns at their pace, masters the unit, and only then moves forward.
              </p>
            </Reveal>
            <ul className="mt-8 space-y-3">
              {features.map((f, i) => (
                <Reveal key={f} delay={i * 50}>
                  <li className="flex items-start gap-3 rounded-xl border border-navy/10 bg-white px-4 py-3">
                    <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-green text-cream"><Check size={12} /></span>
                    <span className="text-sm text-navy">{f}</span>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="bg-beige/60 py-20">
        <div className="container-app">
          <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">How a LIFEPAC unit works</h2></Reveal>
          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {steps.map((s, i) => (
              <Reveal key={s.n} delay={i * 80}>
                <article className="h-full rounded-3xl border border-navy/10 bg-white p-6 shadow-soft">
                  <span className="font-display text-3xl font-extrabold text-green">{s.n}</span>
                  <h3 className="mt-3 font-display text-xl font-bold text-navy">{s.t}</h3>
                  <p className="mt-2 text-sm text-navy/70">{s.d}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="container-app py-20">
        <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Subjects we offer through LIFEPAC</h2></Reveal>
        <div className="mt-8 flex flex-wrap gap-3">
          {subjects.map((s) => (
            <span key={s} className="rounded-full border border-navy/15 bg-cream px-5 py-2 font-medium text-navy">{s}</span>
          ))}
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
