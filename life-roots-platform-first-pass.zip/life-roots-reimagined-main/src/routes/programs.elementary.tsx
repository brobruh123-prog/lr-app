import { createFileRoute } from "@tanstack/react-router";
import { ProgramDetail } from "@/components/site/ProgramDetail";
import { PROGRAM_IMAGES } from "@/components/site/shared";

export const Route = createFileRoute("/programs/elementary")({
  head: () => ({
    meta: [
      { title: "Elementary — Life Roots Schools" },
      { name: "description", content: "Grades 1–5 mastery-based, Christ-centered elementary education in Kigali, Rwanda." },
      { property: "og:title", content: "Elementary at Life Roots" },
      { property: "og:description", content: "Strong foundations in literacy, numeracy, science, and biblical worldview." },
      { property: "og:image", content: PROGRAM_IMAGES.elementary },
      { property: "og:url", content: "/programs/elementary" },
    ],
    links: [{ rel: "canonical", href: "/programs/elementary" }],
  }),
  component: () => (
    <ProgramDetail
      eyebrow="Grades 1–5"
      title="Elementary School"
      subtitle="Strong foundations across literacy, numeracy, science, and biblical worldview — built one mastered skill at a time."
      image={PROGRAM_IMAGES.elementary}
      ageRange="Ages 6–10"
      daysPerWeek="Mon–Fri · Full day"
      ratio="1 : 12"
      subjects={["English Language Arts", "Mathematics", "Science", "Bible", "History & Geography", "French / Kinyarwanda", "ICT", "Art, Music & PE"]}
      outcomes={[
        "Reads fluently with strong comprehension",
        "Confident with arithmetic, fractions, and problem solving",
        "Conducts simple science investigations",
        "Knows the big story of Scripture",
        "Writes clearly with proper structure",
        "Demonstrates self-discipline and kindness",
      ]}
      schedule={[
        { time: "7:50", block: "Arrival, devotion & prayer" },
        { time: "8:15", block: "Math LIFEPAC block" },
        { time: "9:30", block: "English Language Arts" },
        { time: "10:30", block: "Break & outdoor play" },
        { time: "10:50", block: "Science / History rotations" },
        { time: "12:00", block: "Lunch & recess" },
        { time: "13:00", block: "Bible & character lesson" },
        { time: "13:45", block: "Art / Music / PE / ICT" },
        { time: "15:00", block: "Reflection & dismissal" },
      ]}
      about={[
        "Elementary at Life Roots blends the LIFEPAC mastery curriculum with rich whole-class teaching. Students don't move on until they've mastered the concept — and they aren't held back when they're ready to fly.",
        "Bible class, Scripture memorisation, and daily devotions form the spiritual heartbeat. Worldview lessons help students see God's hand in math, science, history, and their own stories.",
        "Outside the books, weekly chapel, service projects, and house-team activities grow character, friendship, and faith.",
      ]}
    />
  ),
});
