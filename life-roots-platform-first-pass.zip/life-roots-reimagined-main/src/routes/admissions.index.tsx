import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal, IMAGES } from "@/components/site/shared";
import { ArrowRight, ClipboardList, FileText, Calendar, Check } from "lucide-react";

export const Route = createFileRoute("/admissions/")({
  head: () => ({
    meta: [
      { title: "Admissions — Life Roots Schools" },
      { name: "description", content: "How to apply to Life Roots Schools in Kigali, Rwanda. A simple, six-step admissions journey." },
      { property: "og:title", content: "Admissions at Life Roots" },
      { property: "og:description", content: "A clear, family-friendly admissions journey." },
      { property: "og:image", content: IMAGES.general29 },
      { property: "og:url", content: "/admissions" },
    ],
    links: [{ rel: "canonical", href: "/admissions" }],
  }),
  component: AdmissionsPage,
});

function AdmissionsPage() {
  const steps = [
    { n: "01", t: "Inquire", d: "Submit an inquiry form or call our admissions team." },
    { n: "02", t: "Visit campus", d: "Tour our Kigali campus, meet our team, and see classrooms in action." },
    { n: "03", t: "Apply online", d: "Submit a complete application with required documents." },
    { n: "04", t: "Assessment", d: "Age-appropriate placement assessment and parent conversation." },
    { n: "05", t: "Decision", d: "Admissions decision shared with the family within two weeks." },
    { n: "06", t: "Enrol", d: "Welcome packet, fee schedule, and onboarding for the new family." },
  ];
  const docs = [
    "Completed application form",
    "Copy of student's birth certificate / ID",
    "Previous school transcript or report",
    "Two passport-style photos",
    "Pastoral or character reference (Grade 6+)",
    "Health and immunisation record",
  ];

  return (
    <PageLayout>
      <PageHero
        eyebrow="Admissions"
        breadcrumb={[{ label: "Admissions" }]}
        title="A simple, six-step admissions journey."
        subtitle="We've designed our process to be clear, personal, and family-friendly. Here's exactly what to expect."
      >
        <div className="flex flex-wrap gap-3">
          <Link to="/admissions/apply" className="inline-flex items-center gap-2 rounded-full bg-green px-6 py-3 text-sm font-semibold text-cream shadow-green hover:bg-green-soft">
            Start application <ArrowRight size={15} />
          </Link>
          <Link to="/admissions/visit" className="inline-flex items-center gap-2 rounded-full border border-cream/30 px-6 py-3 text-sm font-semibold text-cream hover:bg-cream/10">
            <Calendar size={15} /> Book a visit
          </Link>
        </div>
      </PageHero>

      <section className="container-app py-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 60}>
              <article className="relative h-full overflow-hidden rounded-3xl border border-navy/10 bg-white p-7 shadow-soft">
                <span className="absolute right-5 top-5 font-display text-4xl font-extrabold text-green/15">{s.n}</span>
                <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-navy text-cream"><ClipboardList size={20} /></span>
                <h3 className="mt-5 font-display text-xl font-bold text-navy">{s.t}</h3>
                <p className="mt-2 text-sm text-navy/70">{s.d}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-beige/60 py-20">
        <div className="container-app grid gap-12 lg:grid-cols-2">
          <div>
            <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Required documents</h2></Reveal>
            <ul className="mt-8 space-y-3">
              {docs.map((d) => (
                <li key={d} className="flex items-start gap-3 rounded-xl border border-navy/10 bg-white px-4 py-3">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-green text-cream"><Check size={12} /></span>
                  <span className="text-sm text-navy">{d}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">Fees & financial info</h2></Reveal>
            <p className="mt-4 text-navy/75">A detailed fee schedule is shared with families during the admissions process. We are committed to transparency and to making excellent Christ-centered education accessible to our community.</p>
            <p className="mt-3 text-navy/75">For specific tuition information, please <Link to="/contact" className="font-semibold text-green underline-grow">contact our admissions team</Link>.</p>
            <Link to="/faq" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-green underline-grow">
              <FileText size={15} /> See our admissions FAQ
            </Link>
          </div>
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
