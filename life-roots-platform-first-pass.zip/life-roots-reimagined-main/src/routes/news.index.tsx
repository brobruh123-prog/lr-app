import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { Reveal } from "@/components/site/shared";
import { ArrowRight } from "lucide-react";
import { POSTS } from "./news.$slug";

export const Route = createFileRoute("/news/")({
  head: () => ({
    meta: [
      { title: "News & Stories — Life Roots Schools" },
      { name: "description", content: "Latest news, events, and stories from Life Roots Schools in Kigali, Rwanda." },
      { property: "og:title", content: "News & Stories" },
      { property: "og:description", content: "What's growing at Life Roots Schools." },
      { property: "og:url", content: "/news" },
    ],
    links: [{ rel: "canonical", href: "/news" }],
  }),
  component: NewsIndex,
});

function NewsIndex() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="Latest News"
        breadcrumb={[{ label: "News" }]}
        title="What's growing at Life Roots."
        subtitle="Updates from our classrooms, community, and campus."
      />

      <section className="container-app py-20">
        <div className="grid gap-8 lg:grid-cols-3">
          {POSTS.map((p, i) => (
            <Reveal key={p.slug} delay={i * 80}>
              <Link to="/news/$slug" params={{ slug: p.slug }} className="block h-full">
                <article className="group h-full overflow-hidden rounded-3xl bg-white shadow-soft transition-all hover:-translate-y-1 hover:shadow-elegant">
                  <div className="relative h-56 overflow-hidden">
                    <img src={p.img} alt={p.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  </div>
                  <div className="p-7">
                    <div className="text-xs font-semibold uppercase tracking-wider text-green">{p.category} · <span className="text-navy/60">{p.date}</span></div>
                    <h3 className="mt-3 font-display text-xl font-bold text-navy">{p.title}</h3>
                    <p className="mt-3 text-sm text-navy/70">{p.excerpt}</p>
                    <span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-navy">
                      Read article <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </article>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
