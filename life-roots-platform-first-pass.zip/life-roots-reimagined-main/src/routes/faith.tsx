import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { Cross, Heart, Quote, Star, Users } from "lucide-react";

export const Route = createFileRoute("/faith")({
  head: () => ({
    meta: [
      { title: "Faith & Discipleship — Life Roots Schools" },
      { name: "description", content: "Our Christ-centered approach at Life Roots Schools — daily devotions, weekly chapel, biblical worldview, and discipleship in every classroom." },
      { property: "og:title", content: "Faith at Life Roots" },
      { property: "og:description", content: "Discipleship is not an add-on. It's the foundation." },
      { property: "og:image", content: IMAGES.general35 },
      { property: "og:url", content: "/faith" },
    ],
    links: [{ rel: "canonical", href: "/faith" }],
  }),
  component: FaithPage,
});

function FaithPage() {
  const pillars = [
    { icon: Cross, t: "Daily devotions", d: "Every school day begins with Scripture, prayer, and reflection in every classroom." },
    { icon: Users, t: "Weekly chapel", d: "Whole-school worship and biblical teaching that anchors our shared life together." },
    { icon: Heart, t: "Discipleship groups", d: "Small mentor-led groups where students grow in faith and friendship." },
    { icon: Star, t: "Service & missions", d: "Termly service projects in our community and beyond — faith expressed through love." },
  ];
  const beliefs = [
    "We believe the Bible is the inspired, authoritative Word of God.",
    "We believe in one God, eternally existing in three persons: Father, Son, and Holy Spirit.",
    "We believe Jesus Christ is fully God and fully man — the only Savior of the world.",
    "We believe salvation is by grace through faith in Jesus Christ alone.",
    "We believe the Holy Spirit indwells every believer to convict, guide, and empower.",
    "We believe the church is the body of Christ, called to love, serve, and make disciples.",
  ];

  return (
    <PageLayout>
      <PageHero
        eyebrow="Faith & Formation"
        breadcrumb={[{ label: "Faith" }]}
        title="Christ at the center — of every classroom, every relationship, every day."
        subtitle="At Life Roots, faith is not a subject we teach. It's the soil our entire school grows in."
        image={IMAGES.general35}
      />

      <section className="container-app py-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p, i) => (
            <Reveal key={p.t} delay={i * 70}>
              <article className="h-full rounded-3xl border border-navy/8 bg-white p-7 shadow-soft">
                <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-green text-cream"><p.icon size={20} /></span>
                <h3 className="mt-5 font-display text-xl font-bold text-navy">{p.t}</h3>
                <p className="mt-2 text-sm text-navy/70">{p.d}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-beige/60 py-20">
        <div className="container-app">
          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
            <Reveal>
              <div className="relative overflow-hidden rounded-[2rem] shadow-elegant">
                <img src={IMAGES.general29} alt="Worship at Life Roots" className="h-[420px] w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-tr from-navy/40 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6 rounded-2xl bg-white/95 p-5 backdrop-blur">
                  <Quote size={18} className="text-green" />
                  <p className="mt-2 font-serif text-lg italic text-navy">"Train up a child in the way he should go; even when he is old he will not depart from it."</p>
                  <p className="mt-1 text-xs font-semibold text-navy/70">Proverbs 22:6</p>
                </div>
              </div>
            </Reveal>
            <div>
              <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">What we believe</h2></Reveal>
              <ul className="mt-8 space-y-3">
                {beliefs.map((b, i) => (
                  <Reveal key={b} delay={i * 40}>
                    <li className="rounded-xl border border-navy/10 bg-white px-4 py-3 text-sm text-navy">{b}</li>
                  </Reveal>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <CTASection title="Come worship with us" description="Visit a chapel service or talk to our chaplain. We'd love to share our story with you." />
    </PageLayout>
  );
}
