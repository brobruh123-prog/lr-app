import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { Check, GraduationCap, Plane, FileCheck, Building2 } from "lucide-react";

export const Route = createFileRoute("/curriculum/cpp")({
  head: () => ({
    meta: [
      { title: "Canada Pathway Program (CPP) — Life Roots Schools" },
      { name: "description", content: "The CPP Canada Pathway Program at Life Roots Schools — a guided route from Grade 12 to admission at top Canadian universities." },
      { property: "og:title", content: "Canada Pathway Program — Life Roots" },
      { property: "og:description", content: "From Kigali to Canada — a complete pathway from Grade 12 to university admission." },
      { property: "og:image", content: IMAGES.presentation },
      { property: "og:url", content: "/curriculum/cpp" },
    ],
    links: [{ rel: "canonical", href: "/curriculum/cpp" }],
  }),
  component: CPPPage,
});

function CPPPage() {
  const steps = [
    { n: "01", icon: FileCheck, t: "Eligibility & Profile", d: "Grade 11–12 students with strong academic and character standing build their CPP candidate profile." },
    { n: "02", icon: GraduationCap, t: "Academic Prep", d: "Targeted prep for English proficiency tests, university-style writing, and entrance assessments." },
    { n: "03", icon: Building2, t: "University Matching", d: "Personalised advising matches students with partner universities and programs in Canada." },
    { n: "04", icon: Plane, t: "Visa & Departure", d: "Visa documentation, travel logistics, and pre-departure orientation for students and families." },
  ];
  const includes = [
    "Dedicated CPP counsellor from Grade 11 onward",
    "University application strategy and essay coaching",
    "TOEFL / IELTS preparation",
    "Letters of recommendation and transcript packaging",
    "Visa documentation guidance",
    "Pre-departure orientation and Canadian campus connections",
    "Ongoing mentorship in the first year abroad",
  ];

  return (
    <PageLayout>
      <PageHero
        eyebrow="University Pathway"
        breadcrumb={[{ label: "Curriculum", to: "/curriculum" }, { label: "Canada Pathway Program" }]}
        title="From Kigali to Canada — a complete pathway."
        subtitle="CPP is our flagship university pathway. We don't just teach students — we walk with them from Grade 11 all the way to a Canadian university campus."
        image={IMAGES.presentation}
      />

      <section className="container-app py-20">
        <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">How the pathway works</h2></Reveal>
        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 80}>
              <article className="relative h-full overflow-hidden rounded-3xl border border-navy/10 bg-white p-7 shadow-soft">
                <span className="absolute right-5 top-5 font-display text-2xl font-extrabold text-green/30">{s.n}</span>
                <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-navy text-cream"><s.icon size={20} /></span>
                <h3 className="mt-5 font-display text-xl font-bold text-navy">{s.t}</h3>
                <p className="mt-2 text-sm text-navy/70">{s.d}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-beige/60 py-20">
        <div className="container-app">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <Reveal>
              <img src={IMAGES.general29} alt="CPP students" className="rounded-[2rem] shadow-elegant" />
            </Reveal>
            <div>
              <Reveal><h2 className="font-display text-3xl font-bold text-navy sm:text-4xl text-balance">What CPP includes</h2></Reveal>
              <ul className="mt-8 space-y-3">
                {includes.map((f, i) => (
                  <Reveal key={f} delay={i * 50}>
                    <li className="flex items-start gap-3 rounded-xl border border-navy/10 bg-white px-4 py-3">
                      <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-green text-cream"><Check size={12} /></span>
                      <span className="text-sm text-navy">{f}</span>
                    </li>
                  </Reveal>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="container-app py-20">
        <div className="rounded-3xl bg-navy p-10 text-cream shadow-elegant sm:p-14">
          <Reveal>
            <h2 className="font-display text-3xl font-bold sm:text-4xl text-balance">Eligibility</h2>
            <p className="mt-4 max-w-2xl text-cream/80">CPP is open to Life Roots high school students in good academic standing (typically a B+ average), with strong character references and a clear desire to study in Canada. We begin formal advising in Grade 11.</p>
          </Reveal>
        </div>
      </section>

      <CTASection title="Interested in the Canada Pathway?" description="Talk to our admissions team about how CPP works for your child." />
    </PageLayout>
  );
}
