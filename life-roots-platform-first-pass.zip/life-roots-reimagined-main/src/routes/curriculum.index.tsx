import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { ArrowRight, BookOpen, GraduationCap, Globe2 } from "lucide-react";

export const Route = createFileRoute("/curriculum/")({
  head: () => ({
    meta: [
      { title: "Curriculum — Life Roots Schools" },
      { name: "description", content: "LIFEPAC, Sevenstar Online Academy, and the Canada Pathway Program — world-class, biblically grounded learning at Life Roots Schools." },
      { property: "og:title", content: "Curriculum at Life Roots" },
      { property: "og:description", content: "World-class learning, biblically grounded." },
      { property: "og:image", content: IMAGES.lifepac },
      { property: "og:url", content: "/curriculum" },
    ],
    links: [{ rel: "canonical", href: "/curriculum" }],
  }),
  component: CurriculumIndex,
});

const ITEMS = [
  { to: "/curriculum/lifepac", icon: BookOpen, tag: "Mastery-based", title: "LIFEPAC Curriculum", body: "Self-paced biblical worldview workbooks across all core subjects.", img: IMAGES.lifepac },
  { to: "/curriculum/sevenstar", icon: Globe2, tag: "Online", title: "Sevenstar Academy", body: "World-class Christian online courses taught by credentialed teachers.", img: IMAGES.sevenstar },
  { to: "/curriculum/cpp", icon: GraduationCap, tag: "University", title: "Canada Pathway Program", body: "A guided route from Grade 12 to admission at Canadian universities.", img: IMAGES.presentation },
];

function CurriculumIndex() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="Curriculum"
        breadcrumb={[{ label: "Curriculum" }]}
        title="World-class learning, biblically grounded."
        subtitle="Three integrated systems work together so every student is challenged, supported, and prepared for what's next."
      />

      <section className="container-app py-20 sm:py-28">
        <div className="grid gap-8 lg:grid-cols-3">
          {ITEMS.map((it, idx) => (
            <Reveal key={it.to} delay={idx * 80}>
              <Link to={it.to} className="block h-full">
                <article className="group h-full overflow-hidden rounded-3xl border border-navy/8 bg-white shadow-soft transition-all hover:-translate-y-1 hover:shadow-elegant">
                  <div className="relative h-56 overflow-hidden">
                    <img src={it.img} alt={it.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute left-4 top-4 inline-flex items-center gap-2 rounded-full bg-white/95 px-3 py-1.5 text-xs font-semibold text-navy shadow">
                      <it.icon size={13} /> {it.tag}
                    </div>
                  </div>
                  <div className="p-7">
                    <h3 className="font-display text-2xl font-bold text-navy">{it.title}</h3>
                    <p className="mt-3 text-sm text-navy/70">{it.body}</p>
                    <span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-green">
                      Learn more <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </article>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
