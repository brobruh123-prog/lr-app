import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMyRole, type Role } from "@/lib/dashboard.functions";
import { AppShell } from "@/components/app/AppShell";

export const Route = createFileRoute("/app")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Portal — Liferoots Schools" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AppLayout,
});

function AppLayout() {
  const navigate = useNavigate();
  const fetchRole = useServerFn(getMyRole);
  const [state, setState] = useState<{ loading: boolean; role: Role; email: string | null; fullName: string | null }>({
    loading: true, role: null, email: null, fullName: null,
  });

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        navigate({ to: "/auth" });
        return;
      }
      try {
        const info = await fetchRole({ data: undefined });
        if (!mounted) return;
        if (!info.role) {
          setState({ loading: false, role: "student", email: info.email, fullName: info.fullName });
        } else {
          setState({ loading: false, ...info });
        }
      } catch {
        navigate({ to: "/auth" });
      }
    })();
    return () => { mounted = false; };
  }, [fetchRole, navigate]);

  if (state.loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-cream">
        <div className="text-navy/70">Loading your portal…</div>
      </div>
    );
  }
  if (!state.role) return null;

  return (
    <AppShell role={state.role} email={state.email} fullName={state.fullName}>
      <Outlet />
    </AppShell>
  );
}
