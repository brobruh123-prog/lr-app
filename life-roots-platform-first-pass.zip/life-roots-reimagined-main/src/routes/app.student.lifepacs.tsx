import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getStudentSnapshot } from "@/lib/academics.functions";
import { Panel } from "@/components/app/AppShell";
import { LifepacList } from "@/components/app/AcademicViews";

export const Route = createFileRoute("/app/student/lifepacs")({
  ssr: false,
  component: StudentLifepacs,
});

function StudentLifepacs() {
  const fetchSnap = useServerFn(getStudentSnapshot);
  const [snap, setSnap] = useState<any>(null);
  useEffect(() => { fetchSnap({ data: { studentId: null } }).then(setSnap).catch(() => {}); }, [fetchSnap]);
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">My LIFEPACs</h1>
      <Panel title="All Units"><LifepacList lifepacs={snap?.lifepacs ?? []} /></Panel>
    </div>
  );
}
