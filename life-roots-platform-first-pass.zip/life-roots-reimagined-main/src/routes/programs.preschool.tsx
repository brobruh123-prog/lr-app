import { createFileRoute } from "@tanstack/react-router";
import { ProgramDetail } from "@/components/site/ProgramDetail";
import { IMAGES } from "@/components/site/shared";

export const Route = createFileRoute("/programs/preschool")({
  head: () => ({
    meta: [
      { title: "Preschool — Life Roots Schools" },
      { name: "description", content: "Joy-filled, Christ-centered preschool for ages 3–5 in Kigali, Rwanda. Play-based learning that nurtures curiosity, language, and character." },
      { property: "og:title", content: "Preschool at Life Roots" },
      { property: "og:description", content: "Where curiosity meets character — our youngest learners take their first big step." },
      { property: "og:image", content: IMAGES.preschoolGrad },
      { property: "og:url", content: "/programs/preschool" },
    ],
    links: [{ rel: "canonical", href: "/programs/preschool" }],
  }),
  component: () => (
    <ProgramDetail
      eyebrow="Ages 3–5"
      title="Preschool"
      subtitle="A joy-filled, Christ-centered start to school — where children learn through play, story, and Scripture."
      image={IMAGES.preschoolGrad}
      ageRange="Ages 3–5"
      daysPerWeek="Mon–Fri · Half & Full day"
      ratio="1 : 8"
      subjects={["Language & Literacy", "Early Numeracy", "Bible & Worship", "Music & Movement", "Art & Crafts", "Nature & Science", "Social Skills", "Physical Play"]}
      outcomes={[
        "Loves reading and being read to",
        "Recognises letters, sounds, and numbers 1–20",
        "Knows core Bible stories and prays confidently",
        "Shares, takes turns, and resolves small conflicts",
        "Develops fine and gross motor skills",
        "Speaks confidently in English",
      ]}
      schedule={[
        { time: "8:00", block: "Welcome, prayer & devotion" },
        { time: "8:30", block: "Circle time, songs & story" },
        { time: "9:15", block: "Literacy & numeracy stations" },
        { time: "10:15", block: "Snack & outdoor play" },
        { time: "11:00", block: "Themed exploration (science / art)" },
        { time: "12:00", block: "Lunch & quiet time" },
        { time: "13:30", block: "Creative play & dismissal" },
      ]}
      about={[
        "Our Preschool program meets little learners exactly where they are. Through joyful play, intentional story-time, and gentle academic introduction, children build a love for learning that will last a lifetime.",
        "Every day starts with prayer and Scripture, weaves Christ-centered character formation into ordinary moments, and ends with confident, happy children who can't wait to come back tomorrow.",
        "Small class sizes and a low student-to-teacher ratio mean every child is known, seen, and loved by name.",
      ]}
    />
  ),
});
