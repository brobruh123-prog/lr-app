import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useRef, useState } from "react";
import { Send, Sparkles, BookOpen, Cross, GraduationCap, HeartHandshake, MapPin, Brain } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";

export const Route = createFileRoute("/assistant")({
  head: () => ({
    meta: [
      { title: "AI Guide — Life Roots Schools" },
      { name: "description", content: "Ask our AI guide about the Bible, school, study tips, Rwanda, LIFEPAC, the Canada Pathway, and more. Warm, unbiased, and built for students." },
      { property: "og:title", content: "AI Guide — Life Roots Schools" },
      { property: "og:description", content: "A kind, knowledgeable tutor for students learning the Bible, growing in faith, and preparing for university." },
    ],
  }),
  component: AssistantPage,
});

type Suggestion = { icon: typeof BookOpen; label: string; group: string };

const SUGGESTIONS: Suggestion[] = [
  { group: "Bible", icon: BookOpen, label: "Who was King David?" },
  { group: "Bible", icon: Cross, label: "Explain the Beatitudes simply" },
  { group: "Bible", icon: BookOpen, label: "How do I start reading the Bible?" },
  { group: "School", icon: GraduationCap, label: "How does the LIFEPAC curriculum work?" },
  { group: "School", icon: HeartHandshake, label: "Tell me about the Canada Pathway Program" },
  { group: "School", icon: MapPin, label: "What is life like in Kigali, Rwanda?" },
  { group: "Study", icon: Brain, label: "Tips for beating exam anxiety" },
  { group: "Study", icon: GraduationCap, label: "Help me write a Canadian university essay" },
];

function AssistantPage() {
  const [input, setInput] = useState("");
  const transportRef = useRef(new DefaultChatTransport({ api: "/api/chat" }));
  const { messages, sendMessage, status, error } = useChat({
    transport: transportRef.current,
  });
  const isLoading = status === "submitted" || status === "streaming";
  const scrollerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    scrollerRef.current?.scrollTo({ top: scrollerRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [status]);

  const submit = async (text: string) => {
    const value = text.trim();
    if (!value || isLoading) return;
    setInput("");
    await sendMessage({ text: value });
  };

  return (
    <PageLayout>
      <PageHero
        eyebrow="AI Guide"
        title="Ask anything about the Bible, school, or your future"
        subtitle="A warm, patient tutor for students — from scripture and prayer to LIFEPAC, exams, Rwanda, and your path to a Canadian university."
        breadcrumb={[{ label: "AI Guide" }]}
      />

      <section className="container-app -mt-12 pb-24">
        <div className="rounded-[2rem] border border-navy/10 bg-white shadow-elegant overflow-hidden">
          <div className="flex items-center gap-3 border-b border-navy/10 bg-cream/60 px-6 py-4">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-green text-cream">
              <Sparkles size={18} />
            </span>
            <div>
              <p className="font-display font-semibold text-navy">Life Roots Guide</p>
              <p className="text-xs text-navy/60">Bible · School · Study · Rwanda · University</p>
            </div>
          </div>

          <div ref={scrollerRef} className="h-[55vh] min-h-[420px] overflow-y-auto px-4 py-6 sm:px-8">
            {messages.length === 0 && (
              <div className="mx-auto max-w-2xl text-center">
                <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-green/10 text-green">
                  <BookOpen size={22} />
                </div>
                <h2 className="mt-4 font-display text-2xl font-bold text-navy">How can I help you learn today?</h2>
                <p className="mt-2 text-sm text-navy/70">
                  Ask about the Bible, Christian life, our school, LIFEPAC, study skills, Rwanda, or your path to university. I'll give honest, balanced answers — and I'm here as often as you need me.
                </p>
                <div className="mt-6 grid gap-2 sm:grid-cols-2 text-left">
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s.label}
                      onClick={() => submit(s.label)}
                      className="group flex items-center gap-3 rounded-2xl border border-navy/10 bg-cream/40 px-4 py-3 text-sm text-navy transition hover:border-green/40 hover:bg-green/5"
                    >
                      <s.icon size={16} className="text-green shrink-0" />
                      <span className="flex-1">{s.label}</span>
                      <span className="text-[10px] uppercase tracking-wide text-navy/40">{s.group}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mx-auto max-w-3xl space-y-5">
              {messages.map((m: UIMessage) => {
                const text = m.parts
                  .map((p) => (p.type === "text" ? p.text : ""))
                  .join("");
                const isUser = m.role === "user";
                return (
                  <div key={m.id} className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      isUser
                        ? "bg-navy text-cream rounded-br-sm whitespace-pre-wrap"
                        : "bg-cream/70 text-navy rounded-bl-sm border border-navy/5"
                    }`}>
                      {isUser ? (
                        text
                      ) : text ? (
                        <div className="prose prose-sm max-w-none prose-headings:font-display prose-headings:text-navy prose-p:text-navy/85 prose-strong:text-navy prose-a:text-green prose-blockquote:border-l-green prose-blockquote:text-navy/75 prose-blockquote:not-italic prose-li:marker:text-green">
                          <ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown>
                        </div>
                      ) : (
                        <span className="opacity-60">…</span>
                      )}
                    </div>
                  </div>
                );
              })}
              {isLoading && messages[messages.length - 1]?.role === "user" && (
                <div className="flex justify-start">
                  <div className="rounded-2xl rounded-bl-sm border border-navy/5 bg-cream/70 px-4 py-3">
                    <div className="flex gap-1.5">
                      <span className="h-2 w-2 animate-bounce rounded-full bg-green [animation-delay:-0.3s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-green [animation-delay:-0.15s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-green" />
                    </div>
                  </div>
                </div>
              )}
              {error && (
                <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  Something went wrong. Please try again in a moment.
                </div>
              )}
            </div>
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); submit(input); }}
            className="border-t border-navy/10 bg-white p-3 sm:p-4"
          >
            <div className="flex items-end gap-2 rounded-2xl border border-navy/15 bg-cream/40 px-3 py-2 focus-within:border-green/60">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    submit(input);
                  }
                }}
                rows={1}
                placeholder="Ask about a Bible verse, LIFEPAC, study tips, Rwanda, university applications…"
                className="flex-1 resize-none bg-transparent px-2 py-2 text-sm text-navy placeholder:text-navy/40 focus:outline-none max-h-40"
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="grid h-10 w-10 place-items-center rounded-xl bg-green text-cream transition hover:bg-green-soft disabled:opacity-40"
                aria-label="Send"
              >
                <Send size={16} />
              </button>
            </div>
            <p className="mt-2 px-2 text-[11px] text-navy/50">
              A learning companion — not a replacement for your pastor, teacher, or admissions officer. For important decisions, reach out via <span className="underline">/contact</span>.
            </p>
          </form>
        </div>
      </section>
    </PageLayout>
  );
}
