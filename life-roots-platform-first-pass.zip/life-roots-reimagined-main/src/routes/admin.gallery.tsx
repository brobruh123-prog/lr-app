import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, useIsAdmin } from "@/hooks/use-auth";
import { claimAdminIfWhitelisted } from "@/lib/admin.functions";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { IMAGES } from "@/components/site/shared";
import { Trash2, Upload } from "lucide-react";

export const Route = createFileRoute("/admin/gallery")({
  head: () => ({
    meta: [
      { title: "Manage Gallery — Life Roots" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminGalleryPage,
});

const CATEGORIES = ["preschool", "elementary", "middle-school", "high-school", "campus", "events", "general"] as const;

type Photo = {
  id: string;
  image_path: string;
  caption: string | null;
  category: string;
  url: string;
};

function AdminGalleryPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const { isAdmin, checking } = useIsAdmin(user?.id);
  const claimAdmin = useServerFn(claimAdminIfWhitelisted);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("general");
  const [file, setFile] = useState<File | null>(null);

  // Auto-claim admin if the signed-in email is whitelisted
  useEffect(() => {
    if (user && !isAdmin && !checking) {
      claimAdmin({ data: undefined }).catch(() => {});
    }
  }, [user, isAdmin, checking, claimAdmin]);

  const load = useCallback(async () => {
    const { data, error } = await supabase
      .from("gallery_photos")
      .select("id, image_path, caption, category")
      .order("created_at", { ascending: false });
    if (error) { setError(error.message); return; }
    const paths = (data ?? []).map((p) => p.image_path);
    const signed = paths.length
      ? await supabase.storage.from("gallery").createSignedUrls(paths, 3600)
      : { data: [], error: null };
    const byPath = new Map<string, string>();
    (signed.data ?? []).forEach((s) => { if (s.path && s.signedUrl) byPath.set(s.path, s.signedUrl); });
    setPhotos((data ?? []).map((p) => ({ ...p, url: byPath.get(p.image_path) ?? "" })));
  }, []);

  useEffect(() => { if (isAdmin) load(); }, [isAdmin, load]);

  async function onUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !user) return;
    setBusy(true); setError(null);
    try {
      const ext = file.name.split(".").pop() ?? "jpg";
      const path = `${category}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const up = await supabase.storage.from("gallery").upload(path, file, { upsert: false });
      if (up.error) throw up.error;
      const ins = await supabase.from("gallery_photos").insert({
        image_path: path,
        caption: caption || null,
        category,
        created_by: user.id,
      });
      if (ins.error) throw ins.error;
      setFile(null); setCaption("");
      const fileInput = document.getElementById("photo-file") as HTMLInputElement | null;
      if (fileInput) fileInput.value = "";
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setBusy(false);
    }
  }

  async function onDelete(p: Photo) {
    if (!confirm("Delete this photo?")) return;
    setBusy(true); setError(null);
    try {
      const del = await supabase.from("gallery_photos").delete().eq("id", p.id);
      if (del.error) throw del.error;
      await supabase.storage.from("gallery").remove([p.image_path]);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed.");
    } finally {
      setBusy(false);
    }
  }

  async function onSignOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  if (loading) {
    return <PageLayout><div className="container-app py-32 text-center text-navy/60">Loading…</div></PageLayout>;
  }

  if (!user) {
    return (
      <PageLayout>
        <PageHero eyebrow="Staff" title="Sign in required" image={IMAGES.heroA} />
        <section className="container-app py-16 text-center">
          <Link to="/auth" className="inline-block rounded-full bg-green px-6 py-3 font-semibold text-cream">Go to sign in</Link>
        </section>
      </PageLayout>
    );
  }

  if (checking) {
    return <PageLayout><div className="container-app py-32 text-center text-navy/60">Checking access…</div></PageLayout>;
  }

  if (!isAdmin) {
    return (
      <PageLayout>
        <PageHero eyebrow="Staff" title="Not an admin" subtitle="Your account is signed in but isn't authorised to manage the gallery." image={IMAGES.heroA} />
        <section className="container-app py-16 text-center">
          <button onClick={onSignOut} className="rounded-full bg-navy px-6 py-3 font-semibold text-cream">Sign out</button>
        </section>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <PageHero
        eyebrow="Admin"
        title="Manage gallery"
        subtitle="Upload, label and remove gallery photos. Anything you upload is immediately visible on the public gallery."
        image={IMAGES.heroA}
        breadcrumb={[{ label: "Admin" }, { label: "Gallery" }]}
      />

      <section className="container-app py-16">
        <div className="flex items-center justify-between">
          <p className="text-sm text-navy/60">Signed in as <span className="font-semibold text-navy">{user.email}</span></p>
          <button onClick={onSignOut} className="text-sm font-medium text-navy/70 hover:text-navy">Sign out</button>
        </div>

        {error && <div className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

        <form onSubmit={onUpload} className="mt-6 grid gap-4 rounded-3xl bg-white p-6 shadow-soft md:grid-cols-[1fr_1fr_auto]">
          <div>
            <label className="text-sm font-medium text-navy">Photo</label>
            <input
              id="photo-file"
              type="file"
              accept="image/*"
              required
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="mt-1 w-full rounded-xl border border-navy/15 bg-cream px-3 py-2 text-sm"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-sm font-medium text-navy">Category</span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as (typeof CATEGORIES)[number])}
                className="mt-1 w-full rounded-xl border border-navy/15 bg-cream px-3 py-2"
              >
                {CATEGORIES.map((c) => <option key={c} value={c}>{c.replace("-", " ")}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="text-sm font-medium text-navy">Caption (optional)</span>
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                className="mt-1 w-full rounded-xl border border-navy/15 bg-cream px-3 py-2"
              />
            </label>
          </div>
          <button
            type="submit"
            disabled={busy || !file}
            className="inline-flex items-center justify-center gap-2 self-end rounded-full bg-green px-6 py-3 font-semibold text-cream shadow-green transition hover:bg-green-soft disabled:opacity-60"
          >
            <Upload size={16} /> {busy ? "Uploading…" : "Upload"}
          </button>
        </form>

        <h2 className="mt-12 font-display text-2xl font-bold text-navy">All photos ({photos.length})</h2>
        {photos.length === 0 ? (
          <p className="mt-4 text-navy/60">No photos uploaded yet.</p>
        ) : (
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {photos.map((p) => (
              <figure key={p.id} className="group relative overflow-hidden rounded-2xl bg-navy/5">
                <img src={p.url} alt={p.caption ?? ""} className="aspect-square w-full object-cover" loading="lazy" />
                <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-navy/90 to-transparent p-3 text-xs text-cream">
                  <span className="truncate">
                    <span className="rounded-full bg-cream/20 px-2 py-0.5 uppercase tracking-wide">{p.category}</span>
                    {p.caption && <span className="ml-2 opacity-90">{p.caption}</span>}
                  </span>
                  <button
                    onClick={() => onDelete(p)}
                    aria-label="Delete photo"
                    className="rounded-full bg-red-500/90 p-2 text-white opacity-0 transition group-hover:opacity-100"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </figure>
            ))}
          </div>
        )}
      </section>
    </PageLayout>
  );
}
