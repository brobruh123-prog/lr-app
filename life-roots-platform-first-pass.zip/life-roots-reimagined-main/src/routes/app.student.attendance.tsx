import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getStudentSnapshot } from "@/lib/academics.functions";
import { Panel, StatCard } from "@/components/app/AppShell";
import { AttendanceList } from "@/components/app/AcademicViews";

export const Route = createFileRoute("/app/student/attendance")({
  ssr: false,
  component: StudentAttendance,
});

function StudentAttendance() {
  const fetchSnap = useServerFn(getStudentSnapshot);
  const [snap, setSnap] = useState<any>(null);
  useEffect(() => { fetchSnap({ data: { studentId: null } }).then(setSnap).catch(() => {}); }, [fetchSnap]);
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">My Attendance</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Attendance Rate" value={snap?.attendanceRate != null ? `${snap.attendanceRate}%` : "—"} accent="bg-green" />
        <StatCard label="Days Recorded" value={snap?.attendance?.length ?? 0} accent="bg-navy" />
      </div>
      <Panel title="History"><AttendanceList attendance={snap?.attendance ?? []} /></Panel>
    </div>
  );
}
