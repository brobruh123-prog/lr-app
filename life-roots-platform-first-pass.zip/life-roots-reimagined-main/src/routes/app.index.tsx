import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect } from "react";
import { getMyRole } from "@/lib/dashboard.functions";

export const Route = createFileRoute("/app/")({
  ssr: false,
  component: AppIndex,
});

function AppIndex() {
  const navigate = useNavigate();
  const fetchRole = useServerFn(getMyRole);
  useEffect(() => {
    fetchRole({ data: undefined })
      .then(({ role }) => {
        const target = role === "admin" ? "/app/admin"
          : role === "teacher" ? "/app/teacher"
          : role === "parent" ? "/app/parent"
          : "/app/student";
        navigate({ to: target, replace: true });
      })
      .catch(() => navigate({ to: "/auth" }));
  }, [fetchRole, navigate]);
  return <div className="p-10 text-navy/70">Routing…</div>;
}
