import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getAdminOverview } from "@/lib/dashboard.functions";
import { StatCard, Panel } from "@/components/app/AppShell";
import { Pin } from "lucide-react";

export const Route = createFileRoute("/app/admin")({
  ssr: false,
  component: AdminDashboard,
});

function AdminDashboard() {
  const fetchOverview = useServerFn(getAdminOverview);
  const [data, setData] = useState<Awaited<ReturnType<typeof getAdminOverview>> | null>(null);

  useEffect(() => {
    fetchOverview({ data: undefined }).then(setData).catch(() => {});
  }, [fetchOverview]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">Admin Overview</h1>
        <p className="mt-1 text-navy/60 dark:text-cream/60">School at a glance — 2025-2026 academic year.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Students" value={data?.counts.students ?? "—"} accent="bg-green" />
        <StatCard label="Teachers" value={data?.counts.teachers ?? "—"} accent="bg-navy" />
        <StatCard label="Parents" value={data?.counts.parents ?? "—"} accent="bg-yellow-500" />
        <StatCard label="Classes" value={data?.counts.classes ?? "—"} accent="bg-rose-500" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Panel title="Recent Announcements">
            {data?.announcements.length ? (
              <ul className="space-y-3">
                {data.announcements.map((a) => (
                  <li key={a.id} className="rounded-xl border border-navy/10 p-4 dark:border-cream/10">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          {a.pinned && <Pin size={14} className="text-green" />}
                          <h3 className="font-semibold text-navy dark:text-cream">{a.title}</h3>
                        </div>
                        <p className="mt-1 text-sm text-navy/70 dark:text-cream/70">{a.body}</p>
                      </div>
                      <span className="shrink-0 rounded-full bg-navy/5 px-2 py-0.5 text-xs text-navy/60 dark:bg-cream/10 dark:text-cream/60">{a.audience}</span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-navy/60 dark:text-cream/60">No announcements yet.</p>
            )}
          </Panel>
        </div>
        <Panel title="Quick Actions">
          <div className="space-y-2 text-sm">
            <div className="rounded-xl bg-navy/5 p-3 text-navy/70 dark:bg-cream/5 dark:text-cream/70">Add student (Phase 5)</div>
            <div className="rounded-xl bg-navy/5 p-3 text-navy/70 dark:bg-cream/5 dark:text-cream/70">Create class (Phase 5)</div>
            <div className="rounded-xl bg-navy/5 p-3 text-navy/70 dark:bg-cream/5 dark:text-cream/70">Post announcement (Phase 3)</div>
            <div className="rounded-xl bg-navy/5 p-3 text-navy/70 dark:bg-cream/5 dark:text-cream/70">Open calendar (Phase 3)</div>
          </div>
        </Panel>
      </div>
    </div>
  );
}
