import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { claimAdminIfWhitelisted } from "@/lib/admin.functions";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { IMAGES } from "@/components/site/shared";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Life Roots Schools" },
      { name: "description", content: "Sign in to manage the Life Roots Schools gallery." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const claimAdmin = useServerFn(claimAdminIfWhitelisted);
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin + "/auth" },
        });
        if (error) throw error;
        setInfo("Account created. You can sign in now.");
        setMode("signin");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        try {
          await claimAdmin({ data: undefined });
        } catch {
          // non-fatal
        }
        navigate({ to: "/app" });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <PageLayout>
      <PageHero
        eyebrow="Staff"
        title={mode === "signin" ? "Sign in" : "Create account"}
        subtitle="This area is for Life Roots staff. Visitors do not need to sign in."
        image={IMAGES.heroA}
        breadcrumb={[{ label: "Sign in" }]}
      />
      <section className="container-app py-16">
        <form onSubmit={onSubmit} className="mx-auto w-full max-w-md rounded-3xl bg-white p-8 shadow-soft">
          {error && <div className="mb-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
          {info && <div className="mb-4 rounded-xl bg-green-50 px-4 py-3 text-sm text-green-800">{info}</div>}
          <label className="block">
            <span className="text-sm font-medium text-navy">Email</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-xl border border-navy/15 bg-cream px-4 py-3 text-navy outline-none focus:border-green"
            />
          </label>
          <label className="mt-4 block">
            <span className="text-sm font-medium text-navy">Password</span>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-xl border border-navy/15 bg-cream px-4 py-3 text-navy outline-none focus:border-green"
            />
          </label>
          <button
            type="submit"
            disabled={busy}
            className="mt-6 w-full rounded-full bg-green px-5 py-3 font-semibold text-cream shadow-green transition hover:bg-green-soft disabled:opacity-60"
          >
            {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
          </button>
          <button
            type="button"
            onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(null); setInfo(null); }}
            className="mt-4 w-full text-sm text-navy/70 hover:text-navy"
          >
            {mode === "signin" ? "Need an account? Create one" : "Have an account? Sign in"}
          </button>
        </form>
      </section>
    </PageLayout>
  );
}
