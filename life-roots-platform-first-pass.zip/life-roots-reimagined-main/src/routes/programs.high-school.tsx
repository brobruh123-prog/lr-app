import { createFileRoute } from "@tanstack/react-router";
import { ProgramDetail } from "@/components/site/ProgramDetail";
import { PROGRAM_IMAGES } from "@/components/site/shared";

export const Route = createFileRoute("/programs/high-school")({
  head: () => ({
    meta: [
      { title: "High School — Life Roots Schools" },
      { name: "description", content: "Grades 9–12 university-preparatory Christian high school in Kigali, Rwanda — with the Canadian Pathway Program (CPP)." },
      { property: "og:title", content: "High School at Life Roots" },
      { property: "og:description", content: "University-ready scholars on a clear Canadian pathway." },
      { property: "og:image", content: PROGRAM_IMAGES.highSchool },
      { property: "og:url", content: "/programs/high-school" },
    ],
    links: [{ rel: "canonical", href: "/programs/high-school" }],
  }),
  component: () => (
    <ProgramDetail
      eyebrow="Grades 9–12"
      title="High School"
      subtitle="A university-preparatory program that opens doors to Canadian universities through the CPP pathway."
      image={PROGRAM_IMAGES.highSchool}
      ageRange="Ages 14–18"
      daysPerWeek="Mon–Fri · Full day"
      ratio="1 : 14"
      subjects={["English / Literature", "Algebra I & II, Geometry, Pre-Calc", "Biology, Chemistry, Physics", "Bible & Apologetics", "World History & Civics", "French", "Computer Science", "Electives via Sevenstar"]}
      outcomes={[
        "Earns a US-accredited high school diploma",
        "Eligible for the Canada Pathway Program (CPP)",
        "Writes university-level research papers",
        "Demonstrates leadership in service or club",
        "Articulates a thoughtful Christian worldview",
        "Builds a personal portfolio for university applications",
      ]}
      schedule={[
        { time: "7:40", block: "Chapel / devotion (rotating)" },
        { time: "8:15", block: "Period 1 — Math" },
        { time: "9:25", block: "Period 2 — Science" },
        { time: "10:35", block: "Break" },
        { time: "10:55", block: "Period 3 — English / Literature" },
        { time: "12:05", block: "Lunch & mentor time" },
        { time: "13:00", block: "Period 4 — Bible / History" },
        { time: "14:00", block: "Sevenstar elective / lab" },
        { time: "15:10", block: "Sports, leadership or research" },
      ]}
      about={[
        "Life Roots High School prepares students for life beyond graduation — academically, spiritually, and personally. Our students earn a US-accredited high school diploma and many continue directly into the Canadian Pathway Program.",
        "Core subjects use LIFEPAC mastery learning while electives and AP-style enrichment come through Sevenstar Online Academy, giving every student a flexible, deep, and personalized course load.",
        "University counselling begins in Grade 9. By Grade 12, students have written application essays, sat external exams, and built a portfolio that opens doors to top universities in Canada and beyond.",
      ]}
    />
  ),
});
