import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { IMAGES } from "@/components/site/shared";

export type NewsPost = {
  slug: string;
  title: string;
  date: string;
  category: string;
  excerpt: string;
  img: string;
  body: string[];
};

export const POSTS: NewsPost[] = [
  {
    slug: "end-of-term-presentation-2024",
    title: "Celebrating an extraordinary 2024 end-of-term",
    date: "Dec 2024",
    category: "Community",
    excerpt: "Families, students, and staff gathered for a beautiful afternoon of music, reflection, and celebration.",
    img: IMAGES.presentation,
    body: [
      "There is something special about gathering as a school community. This December, our families filled the campus for an end-of-term celebration that was equal parts joyful and worshipful.",
      "Students performed pieces they had been preparing for weeks — choir, drama, recitations from Scripture, and original poems. Teachers shared moments from the term and we honoured students who had grown remarkably in character, service, and academics.",
      "More than the performances, what stood out was the spirit of the room — gratitude, togetherness, and the quiet sense that the year had been full of God's faithfulness. We can't wait to see what 2025 holds.",
    ],
  },
  {
    slug: "preschool-graduation-2024",
    title: "Our littlest scholars take their first big step",
    date: "Dec 2024",
    category: "Preschool",
    excerpt: "Caps, gowns, and very big smiles — preschool graduation 2024 was unforgettable.",
    img: IMAGES.preschoolGrad,
    body: [
      "There are few sights as wonderful as a four-year-old in a graduation cap. This December our preschool families celebrated the children who are moving on to Kindergarten.",
      "Each child received a personal blessing, a small Bible, and a parent reflection. We sang songs from the year, read favourite stories one last time, and prayed over every child by name.",
      "To our preschool parents — thank you for trusting us with these precious years. We're cheering for every child as they take this next big step.",
    ],
  },
  {
    slug: "us-accredited-2025",
    title: "Life Roots is now fully US-accredited",
    date: "Jan 2025",
    category: "Academics",
    excerpt: "A milestone for our students and families — Life Roots Schools has achieved full US accreditation.",
    img: IMAGES.accredited,
    body: [
      "We are thrilled to announce that Life Roots Schools has achieved full US accreditation. This is the culmination of years of careful work by our team to align curriculum, instruction, assessment, and policies with international standards.",
      "What does this mean for our students? A Life Roots diploma is now recognised by universities across North America and beyond. Students transferring in or graduating out can do so seamlessly. And our families can be fully confident in the academic foundation we offer.",
      "Most importantly, this accreditation reinforces what we have always believed: world-class academics and Christ-centered formation are not in competition. They flourish together.",
    ],
  },
];

export const Route = createFileRoute("/news/$slug")({
  loader: ({ params }) => {
    const post = POSTS.find((p) => p.slug === params.slug);
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => {
    const post = loaderData?.post;
    if (!post) {
      return { meta: [{ title: "Article — Life Roots Schools" }] };
    }
    return {
      meta: [
        { title: `${post.title} — Life Roots Schools` },
        { name: "description", content: post.excerpt },
        { property: "og:title", content: post.title },
        { property: "og:description", content: post.excerpt },
        { property: "og:image", content: post.img },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `/news/${post.slug}` },
      ],
      links: [{ rel: "canonical", href: `/news/${post.slug}` }],
    };
  },
  component: NewsArticle,
  notFoundComponent: () => (
    <div className="container-app py-40 text-center">
      <h1 className="font-display text-3xl font-bold text-navy">Article not found</h1>
      <Link to="/news" className="mt-6 inline-flex rounded-full bg-green px-5 py-2.5 text-sm font-semibold text-cream">Back to news</Link>
    </div>
  ),
});

import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";

function NewsArticle() {
  const { post } = Route.useLoaderData();
  return (
    <PageLayout>
      <PageHero
        eyebrow={`${post.category} · ${post.date}`}
        breadcrumb={[{ label: "News", to: "/news" }, { label: post.title }]}
        title={post.title}
        image={post.img}
      />
      <article className="container-app py-20">
        <div className="mx-auto max-w-3xl">
          <img src={post.img} alt={post.title} className="rounded-3xl shadow-elegant" />
          <div className="prose-content mt-10 space-y-6 text-lg leading-relaxed text-navy/80">
            {post.body.map((para: string, i: number) => <p key={i}>{para}</p>)}
          </div>
          <div className="mt-12 flex flex-wrap gap-3">
            <Link to="/news" className="inline-flex items-center gap-2 rounded-full border border-navy/15 px-5 py-2.5 text-sm font-semibold text-navy hover:bg-navy hover:text-cream">
              ← All news
            </Link>
          </div>
        </div>
      </article>
      <CTASection />
    </PageLayout>
  );
}
