import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { IMAGES, Reveal } from "@/components/site/shared";
import { Award, Compass, Cross, Heart, Sparkles, Users } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Life Roots Schools" },
      { name: "description", content: "Our story, mission, vision, and leadership team at Life Roots Schools — a Christian international school in Kigali, Rwanda." },
      { property: "og:title", content: "About Life Roots Schools" },
      { property: "og:description", content: "A Christ-centered school developing students who are academically strong, spiritually grounded, and globally prepared." },
      { property: "og:image", content: IMAGES.general35 },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  const values = [
    { icon: Cross, t: "Christ at the Center", d: "Every decision, every classroom, every relationship anchored in the Gospel." },
    { icon: Compass, t: "Excellence", d: "We pursue academic and personal excellence as worship — doing all things heartily, as for the Lord." },
    { icon: Heart, t: "Compassion", d: "We love our students, families, and community well, in word and in deed." },
    { icon: Users, t: "Community", d: "Families, teachers, and students learning, serving, and growing together." },
    { icon: Sparkles, t: "Innovation", d: "We adopt the best tools and methods to serve each unique learner." },
    { icon: Award, t: "Integrity", d: "Truthful, accountable, and faithful in all we do — when seen and unseen." },
  ];
  const leaders = [
    { name: "Director", role: "Head of School", initials: "DH" },
    { name: "Academic Dean", role: "Curriculum & Instruction", initials: "AD" },
    { name: "Chaplain", role: "Faith & Discipleship", initials: "CH" },
    { name: "Admissions Lead", role: "Family Experience", initials: "AL" },
  ];

  return (
    <PageLayout>
      <PageHero
        eyebrow="Our Story"
        breadcrumb={[{ label: "About" }]}
        title="A school built to develop the whole student."
        subtitle="Life Roots Schools exists to graduate young men and women who think clearly, live faithfully, serve generously, and lead globally."
        image={IMAGES.general35}
      />

      <section className="container-app py-20 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <Reveal>
            <img src={IMAGES.general29} alt="Students at Life Roots" className="rounded-[2rem] shadow-elegant" />
          </Reveal>
          <div>
            <Reveal><h2 className="font-display text-4xl font-bold text-navy sm:text-5xl text-balance">Our Mission</h2></Reveal>
            <Reveal delay={80}>
              <p className="mt-5 text-lg text-navy/75">
                To develop students academically, spiritually, and personally — preparing them to live with purpose, serve with compassion, and lead with integrity wherever God calls them.
              </p>
            </Reveal>
            <Reveal delay={140}>
              <h3 className="mt-10 font-display text-2xl font-bold text-navy">Our Vision</h3>
              <p className="mt-3 text-navy/75">
                A generation of Christ-centered learners — rooted in truth, equipped for excellence, and ready to bring light to every sphere of influence.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="bg-beige/60 py-20 sm:py-28">
        <div className="container-app">
          <div className="mx-auto max-w-2xl text-center">
            <Reveal><h2 className="font-display text-4xl font-bold text-navy sm:text-5xl text-balance">Our Values</h2></Reveal>
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {values.map((v, i) => (
              <Reveal key={v.t} delay={i * 60}>
                <article className="h-full rounded-3xl border border-navy/8 bg-white p-7 shadow-soft">
                  <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-green text-cream"><v.icon size={20} /></span>
                  <h3 className="mt-5 font-display text-xl font-bold text-navy">{v.t}</h3>
                  <p className="mt-2 text-sm text-navy/70">{v.d}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="container-app py-20 sm:py-28">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal><h2 className="font-display text-4xl font-bold text-navy sm:text-5xl text-balance">Leadership</h2></Reveal>
          <Reveal delay={80}><p className="mt-4 text-navy/70">Educators, pastors, and parents serving our school community.</p></Reveal>
        </div>
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {leaders.map((l, i) => (
            <Reveal key={l.role} delay={i * 60}>
              <article className="rounded-3xl border border-navy/8 bg-white p-6 text-center shadow-soft">
                <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-navy font-display text-2xl font-bold text-cream">{l.initials}</div>
                <h3 className="mt-5 font-display text-lg font-bold text-navy">{l.name}</h3>
                <p className="mt-1 text-sm text-navy/60">{l.role}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="container-app pb-20">
        <div className="rounded-3xl border border-navy/10 bg-cream p-10 text-center">
          <Reveal>
            <h3 className="font-display text-2xl font-bold text-navy">Accreditation</h3>
            <p className="mx-auto mt-3 max-w-2xl text-navy/70">
              Life Roots Schools is US-accredited and partners with internationally recognized programs to ensure our students graduate with credentials that open doors worldwide.
            </p>
            <img src={IMAGES.accredited} alt="US Accredited" className="mx-auto mt-6 h-16 object-contain" />
          </Reveal>
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
