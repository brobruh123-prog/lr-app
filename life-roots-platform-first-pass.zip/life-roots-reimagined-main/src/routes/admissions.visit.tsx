import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { ContactForm } from "@/components/site/ContactForm";

export const Route = createFileRoute("/admissions/visit")({
  head: () => ({
    meta: [
      { title: "Book a Visit — Life Roots Schools" },
      { name: "description", content: "Schedule a campus visit to Life Roots Schools in Kigali, Rwanda. Meet our team and see classrooms in action." },
      { property: "og:title", content: "Book a Visit — Life Roots" },
      { property: "og:description", content: "Come and see Life Roots Schools in person." },
      { property: "og:url", content: "/admissions/visit" },
    ],
    links: [{ rel: "canonical", href: "/admissions/visit" }],
  }),
  component: VisitPage,
});

function VisitPage() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="Come and see"
        breadcrumb={[{ label: "Admissions", to: "/admissions" }, { label: "Book a visit" }]}
        title="Book a campus visit."
        subtitle="Tours are by appointment Monday to Friday. Choose a date and our admissions team will confirm by email."
      />
      <section className="container-app py-20">
        <div className="mx-auto max-w-2xl">
          <ContactForm title="Book your visit" fields="visit" submitLabel="Request a visit" />
        </div>
      </section>
    </PageLayout>
  );
}
