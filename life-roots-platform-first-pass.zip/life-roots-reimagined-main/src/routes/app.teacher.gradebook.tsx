import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getTeacherWorkspace, recordGrade } from "@/lib/academics.functions";
import { Panel } from "@/components/app/AppShell";

export const Route = createFileRoute("/app/teacher/gradebook")({
  ssr: false,
  component: Gradebook,
});

function Gradebook() {
  const fetchWs = useServerFn(getTeacherWorkspace);
  const submit = useServerFn(recordGrade);
  const [ws, setWs] = useState<any>(null);
  const [form, setForm] = useState({
    studentId: "", subjectId: "", classId: "",
    category: "quiz", title: "", score: 0, maxScore: 100, weight: 1, term: "Term 1",
  });
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => { fetchWs({ data: undefined }).then(setWs).catch(() => {}); }, [fetchWs]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    try {
      await submit({ data: { ...form, classId: form.classId || null, score: Number(form.score), maxScore: Number(form.maxScore), weight: Number(form.weight) } });
      setMsg("✓ Grade saved");
      setForm({ ...form, title: "", score: 0 });
    } catch (err: any) {
      setMsg("Error: " + (err.message ?? "failed"));
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">Gradebook</h1>
        <p className="mt-1 text-navy/60 dark:text-cream/60">Record a quiz, test, assignment, or exam grade.</p>
      </div>
      <Panel title="New Grade Entry">
        <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Student">
            <select required value={form.studentId} onChange={(e) => setForm({ ...form, studentId: e.target.value })} className={inputCls}>
              <option value="">Select student…</option>
              {ws?.students?.map((s: any) => <option key={s.id} value={s.id}>{s.full_name} — {s.grade_level}</option>)}
            </select>
          </Field>
          <Field label="Subject">
            <select required value={form.subjectId} onChange={(e) => setForm({ ...form, subjectId: e.target.value })} className={inputCls}>
              <option value="">Select subject…</option>
              {ws?.subjects?.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="Category">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={inputCls}>
              {["quiz","test","assignment","exam","project","homework"].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Term">
            <select value={form.term} onChange={(e) => setForm({ ...form, term: e.target.value })} className={inputCls}>
              {["Term 1","Term 2","Term 3"].map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Title">
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className={inputCls} placeholder="Chapter 3 Quiz" />
          </Field>
          <Field label="Weight">
            <input type="number" step="0.1" min="0.1" value={form.weight} onChange={(e) => setForm({ ...form, weight: Number(e.target.value) })} className={inputCls} />
          </Field>
          <Field label="Score">
            <input required type="number" step="0.1" min="0" value={form.score} onChange={(e) => setForm({ ...form, score: Number(e.target.value) })} className={inputCls} />
          </Field>
          <Field label="Max Score">
            <input required type="number" step="0.1" min="0.1" value={form.maxScore} onChange={(e) => setForm({ ...form, maxScore: Number(e.target.value) })} className={inputCls} />
          </Field>
          <div className="sm:col-span-2 flex items-center justify-between">
            {msg && <span className="text-sm text-navy/70 dark:text-cream/70">{msg}</span>}
            <button className="ml-auto rounded-full bg-green px-6 py-2 text-sm font-semibold text-cream shadow-green hover:bg-green/90">Save Grade</button>
          </div>
        </form>
      </Panel>
    </div>
  );
}

const inputCls = "w-full rounded-xl border border-navy/15 bg-white px-3 py-2 text-sm text-navy dark:bg-navy/60 dark:text-cream dark:border-cream/15";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-navy/60 dark:text-cream/60">{label}</span>
      {children}
    </label>
  );
}
