import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { CTASection } from "@/components/site/CTASection";
import { Plus, Minus } from "lucide-react";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Life Roots Schools" },
      { name: "description", content: "Frequently asked questions about admissions, curriculum, faith, and campus life at Life Roots Schools in Kigali, Rwanda." },
      { property: "og:title", content: "FAQ — Life Roots" },
      { property: "og:description", content: "Answers to the questions families ask most." },
      { property: "og:url", content: "/faq" },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: FAQS.map((f) => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      }),
    }],
  }),
  component: FAQPage,
});

const FAQS = [
  { q: "What ages and grades do you accept?", a: "We accept students from preschool (age 3) through Grade 12." },
  { q: "Where is Life Roots Schools located?", a: "Our campus is in Kigali, Rwanda." },
  { q: "Is Life Roots accredited?", a: "Yes. Life Roots Schools is fully US-accredited, and our diploma is recognised by universities across North America and beyond." },
  { q: "What curriculum do you use?", a: "We use LIFEPAC as our mastery-based core curriculum, complemented by Sevenstar Online Academy for advanced and elective courses." },
  { q: "What is the Canada Pathway Program (CPP)?", a: "CPP is our flagship university pathway — a guided route from Grade 11–12 to admission at partner universities in Canada. It includes academic prep, application support, and visa guidance." },
  { q: "What is the language of instruction?", a: "English. We also teach French and offer Kinyarwanda where appropriate to the grade." },
  { q: "Are you a faith-based school?", a: "Yes. Life Roots is a Christ-centered school. Every classroom integrates a biblical worldview, and we hold daily devotions and weekly chapel." },
  { q: "Do families need to be Christian to apply?", a: "No. We welcome families from all backgrounds who are comfortable with our Christ-centered identity and curriculum." },
  { q: "What are class sizes like?", a: "Small. We maintain a low student-to-teacher ratio so every child is known by name and supported personally." },
  { q: "How do I start the admissions process?", a: "Begin by submitting an inquiry on our Apply page, or book a visit to tour the campus first. Our admissions team will guide you from there." },
  { q: "Do you offer financial aid?", a: "We are committed to keeping excellent Christ-centered education accessible. Please contact our admissions team to discuss." },
  { q: "Can students transfer in mid-year?", a: "In most cases yes, depending on grade level and availability. An assessment helps us place students correctly." },
];

function FAQPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <PageLayout>
      <PageHero
        eyebrow="Answers"
        breadcrumb={[{ label: "FAQ" }]}
        title="Frequently asked questions."
        subtitle="Can't find your answer? We'd love to talk."
      />

      <section className="container-app py-20">
        <div className="mx-auto max-w-3xl space-y-3">
          {FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <article key={f.q} className="overflow-hidden rounded-2xl border border-navy/10 bg-white shadow-soft">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 p-5 text-left"
                >
                  <span className="font-display text-lg font-semibold text-navy">{f.q}</span>
                  <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${isOpen ? "bg-navy text-cream" : "bg-green/10 text-green"}`}>
                    {isOpen ? <Minus size={16} /> : <Plus size={16} />}
                  </span>
                </button>
                {isOpen && (
                  <div className="border-t border-navy/10 p-5 text-navy/75">{f.a}</div>
                )}
              </article>
            );
          })}
        </div>

        <div className="mx-auto mt-12 max-w-3xl rounded-3xl border border-green/30 bg-green/5 p-8 text-center">
          <h3 className="font-display text-2xl font-bold text-navy">Still have a question?</h3>
          <p className="mt-2 text-navy/70">Our admissions team is happy to help.</p>
          <Link to="/contact" className="mt-5 inline-flex items-center gap-2 rounded-full bg-green px-6 py-3 text-sm font-semibold text-cream hover:bg-green-soft">
            Contact us
          </Link>
        </div>
      </section>

      <CTASection />
    </PageLayout>
  );
}
