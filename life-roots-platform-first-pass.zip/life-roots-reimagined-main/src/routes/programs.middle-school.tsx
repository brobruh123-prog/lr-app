import { createFileRoute } from "@tanstack/react-router";
import { ProgramDetail } from "@/components/site/ProgramDetail";
import { PROGRAM_IMAGES } from "@/components/site/shared";

export const Route = createFileRoute("/programs/middle-school")({
  head: () => ({
    meta: [
      { title: "Middle School — Life Roots Schools" },
      { name: "description", content: "Grades 6–8 Christ-centered middle school in Kigali, Rwanda. Critical thinking, ownership, and identity in Christ." },
      { property: "og:title", content: "Middle School at Life Roots" },
      { property: "og:description", content: "Confidence, critical thinking, and identity rooted in Christ." },
      { property: "og:image", content: PROGRAM_IMAGES.middleSchool },
      { property: "og:url", content: "/programs/middle-school" },
    ],
    links: [{ rel: "canonical", href: "/programs/middle-school" }],
  }),
  component: () => (
    <ProgramDetail
      eyebrow="Grades 6–8"
      title="Middle School"
      subtitle="The transition years — where students take ownership of their learning, faith, and friendships."
      image={PROGRAM_IMAGES.middleSchool}
      ageRange="Ages 11–13"
      daysPerWeek="Mon–Fri · Full day"
      ratio="1 : 14"
      subjects={["English & Literature", "Pre-Algebra & Algebra I", "Life & Physical Science", "Bible & Worldview", "World History", "French", "ICT & Coding", "PE & Health", "Arts elective"]}
      outcomes={[
        "Thinks critically and asks good questions",
        "Writes structured, evidence-based essays",
        "Solves multi-step math problems with confidence",
        "Articulates and defends Christian beliefs",
        "Manages a personal study schedule",
        "Leads small group discussions and service projects",
      ]}
      schedule={[
        { time: "7:45", block: "Devotion & mentor check-in" },
        { time: "8:10", block: "Block 1 — Math / Algebra" },
        { time: "9:20", block: "Block 2 — English & Literature" },
        { time: "10:30", block: "Break" },
        { time: "10:50", block: "Block 3 — Science" },
        { time: "12:00", block: "Lunch & house team" },
        { time: "13:00", block: "Bible & worldview" },
        { time: "13:50", block: "History / French / Coding" },
        { time: "15:00", block: "Sports, arts or service club" },
      ]}
      about={[
        "Middle school is a season of huge growth. Our students are stretched academically while being deeply supported pastorally — every student has a mentor teacher who knows them well.",
        "We use LIFEPAC for core subjects and Sevenstar Online Academy for selected electives, giving students rigorous content paired with the joy of choice.",
        "Weekly chapel, small group discipleship, and service projects build the spiritual maturity that will carry them into high school and beyond.",
      ]}
    />
  ),
});
