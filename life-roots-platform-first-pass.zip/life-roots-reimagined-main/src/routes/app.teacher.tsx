import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getTeacherWorkspace } from "@/lib/academics.functions";
import { StatCard, Panel } from "@/components/app/AppShell";

export const Route = createFileRoute("/app/teacher")({
  ssr: false,
  component: TeacherDashboard,
});

function TeacherDashboard() {
  const fetchWs = useServerFn(getTeacherWorkspace);
  const [ws, setWs] = useState<any>(null);
  useEffect(() => { fetchWs({ data: undefined }).then(setWs).catch(() => {}); }, [fetchWs]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-navy dark:text-cream">Teacher Dashboard</h1>
        <p className="mt-1 text-navy/60 dark:text-cream/60">Manage your classes, enter grades, and mark attendance.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Classes" value={ws?.classes?.length ?? "—"} accent="bg-green" />
        <StatCard label="Students" value={ws?.students?.length ?? "—"} accent="bg-navy" />
        <StatCard label="Subjects" value={ws?.subjects?.length ?? "—"} accent="bg-yellow-500" />
        <StatCard label="Term" value="Term 1" accent="bg-rose-500" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Quick Actions">
          <div className="grid gap-3 sm:grid-cols-2">
            <Link to="/app/teacher/gradebook" className="rounded-xl bg-green px-4 py-3 text-center text-sm font-semibold text-cream shadow-green hover:bg-green/90">Enter Grades</Link>
            <Link to="/app/teacher/attendance" className="rounded-xl bg-navy px-4 py-3 text-center text-sm font-semibold text-cream hover:bg-navy/90">Mark Attendance</Link>
          </div>
        </Panel>
        <Panel title="My Classes">
          {ws?.classes?.length ? (
            <ul className="space-y-2">
              {ws.classes.map((c: any) => (
                <li key={c.id} className="flex items-center justify-between rounded-xl border border-navy/10 px-3 py-2 dark:border-cream/10">
                  <div>
                    <div className="font-semibold text-navy dark:text-cream">{c.name}</div>
                    <div className="text-xs text-navy/60 dark:text-cream/60">{c.grade_level} · {c.academic_year}</div>
                  </div>
                  <span className="text-xs text-navy/60 dark:text-cream/60">
                    {ws.students.filter((s: any) => s.class_id === c.id).length} students
                  </span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-navy/60 dark:text-cream/60">No classes assigned.</p>}
        </Panel>
      </div>
    </div>
  );
}
