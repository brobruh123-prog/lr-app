import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { ContactForm } from "@/components/site/ContactForm";
import { Mail, MapPin, Phone, Clock } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Life Roots Schools" },
      { name: "description", content: "Get in touch with Life Roots Schools in Kigali, Rwanda. Phone, email, and contact form." },
      { property: "og:title", content: "Contact Life Roots" },
      { property: "og:description", content: "We'd love to hear from you." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="Get in touch"
        breadcrumb={[{ label: "Contact" }]}
        title="We'd love to hear from you."
        subtitle="Reach out with any question — admissions, partnerships, prayer, or just to say hello."
      />

      <section className="container-app py-20">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-6">
            {[
              { icon: MapPin, k: "Visit us", v: "Kigali, Rwanda" },
              { icon: Phone, k: "Call us", v: "+250 788 000 000" },
              { icon: Mail, k: "Email us", v: "hello@liferootsschools.com" },
              { icon: Clock, k: "Office hours", v: "Mon–Fri · 7:30 AM – 4:00 PM" },
            ].map((it) => (
              <div key={it.k} className="flex items-start gap-4 rounded-3xl border border-navy/10 bg-white p-5 shadow-soft">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-green text-cream"><it.icon size={20} /></span>
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-navy/60">{it.k}</div>
                  <div className="mt-0.5 font-display text-lg font-bold text-navy">{it.v}</div>
                </div>
              </div>
            ))}

            <div className="aspect-[4/3] overflow-hidden rounded-3xl border border-navy/10 bg-navy/5">
              <iframe
                title="Kigali map"
                src="https://www.openstreetmap.org/export/embed.html?bbox=30.04%2C-1.97%2C30.12%2C-1.93&layer=mapnik"
                className="h-full w-full"
                loading="lazy"
              />
            </div>
          </div>

          <ContactForm title="Send us a message" />
        </div>
      </section>
    </PageLayout>
  );
}
