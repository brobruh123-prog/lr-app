
# Liferoots School Management Platform — Build Plan

The full spec is a 5-phase build. I'll ship each phase end-to-end, you approve, then I move on. Marketing site stays untouched; the SMS lives under `/app`.

## Phase 1 — Foundations (this phase)

**Branding**
- Wire "Liferoots" everywhere (one word). Wordmark in `SiteNav` until you upload the logo file — once uploaded I swap it in.
- Reuse existing navy/cream palette; add dashboard tokens (sidebar, card, chart colors) + dark mode toggle.

**Auth & roles**
- Roles enum: `admin | teacher | student | parent` (extends current `app_role`).
- `profiles` table (full_name, avatar, phone, role-specific fields).
- `students`, `parents`, `teachers`, `classes`, `enrollments`, `parent_student_links` tables.
- Email/password + Google sign-in on `/auth`. Brukmeb/Brukambes auto-promoted to admin (already wired).
- Protected `/app/*` subtree via `_authenticated` layout; role-based redirect to the right dashboard.

**Database (Phase 1 tables)**
profiles, students, parents, teachers, classes, subjects, enrollments, parent_student_links, announcements, notifications

**Shell UI**
- `/app` shared layout: collapsible sidebar (role-aware nav), top bar (notifications bell, profile menu, dark mode), responsive mobile drawer.
- Four dashboard skeletons (`/app/admin`, `/app/teacher`, `/app/student`, `/app/parent`) with summary cards.

**Seed data**: 1 admin (you), 3 teachers, 5 students, 2 parents, 3 classes, sample announcements.

## Phase 2 — Academics core
LIFEPAC tracking (pending/completed, progress %, teacher comments), grades (quizzes/tests/assignments/exams), attendance (daily marking + stats), subject averages, GPA calc, student + parent read views.

## Phase 3 — Calendar & communications
Full calendar (month/week/day, color-coded categories, permissions, reminders, search/filter, ICS export, print), parent↔teacher messaging, newsletters, notification system (in-app + email).

## Phase 4 — Report cards & extracurriculars
PDF report card generation (current + historical), principal/teacher remarks, extracurriculars (sports, clubs, competitions, leadership, service hours, badges, certificates).

## Phase 5 — Admin power tools & analytics
Full CRUD for students/parents/teachers/classes, enrollment management, grading-system config, school-wide analytics dashboard (performance trends, attendance reports, charts), CSV/PDF export.

## Technical notes
- Stack: TanStack Start + Lovable Cloud (already enabled). RLS on every table, `has_role()` helper already exists.
- All schema changes via migrations with explicit GRANTs.
- Each phase: migration → server fns → UI → seed/verify.

## What I need from you to start Phase 1
1. **Upload the Liferoots logo** (PNG or SVG) — drop it in chat.
2. Confirm sign-off on this phased plan.

Once you approve, I'll run the Phase 1 migration, scaffold the `/app` shell, and seed demo data in one go.
